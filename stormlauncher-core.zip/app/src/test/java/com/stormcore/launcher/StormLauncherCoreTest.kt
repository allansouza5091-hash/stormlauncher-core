package com.stormcore.launcher

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.stormcore.launcher.config.ConfigRepository
import com.stormcore.launcher.config.EnvironmentStatus
import com.stormcore.launcher.config.FpsLimit
import com.stormcore.launcher.config.PerformanceProfile
import com.stormcore.launcher.config.ResolutionScale
import com.stormcore.launcher.config.ShaderFilter
import com.stormcore.launcher.controls.ControllerInputListener
import com.stormcore.launcher.controls.GamepadButton
import com.stormcore.launcher.controls.InputState
import com.stormcore.launcher.controls.UnifiedInputHub
import com.stormcore.launcher.storage.StorageManager
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class StormLauncherCoreTest {

    @Test
    fun `config repository persists graphics and hud coordinates`() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val repo = ConfigRepository(ctx)
        repo.updateConfig {
            it.copy(
                performanceProfile = PerformanceProfile.MAX,
                resolutionScale = ResolutionScale.SCALE_1_25,
                fpsLimit = FpsLimit.UNLIMITED,
                shaderFilter = ShaderFilter.CEL_SHADING,
                vsyncEnabled = false
            )
        }
        val reloaded = ConfigRepository(ctx).config.value
        assertEquals(PerformanceProfile.MAX, reloaded.performanceProfile)
        assertEquals(ResolutionScale.SCALE_1_25, reloaded.resolutionScale)
        assertEquals(FpsLimit.UNLIMITED, reloaded.fpsLimit)
        assertEquals(ShaderFilter.CEL_SHADING, reloaded.shaderFilter)
        assertEquals(false, reloaded.vsyncEnabled)
    }

    @Test
    fun `unified input hub merges virtual and physical inputs`() {
        var latest = InputState()
        val hub = UnifiedInputHub(object : ControllerInputListener {
            override fun onInputStateChanged(state: InputState) {
                latest = state
            }
        })

        hub.updateVirtualAnalog(0.5f, -0.25f)
        hub.updateVirtualButtons(setOf(GamepadButton.A), GamepadButton.A, true)
        hub.updatePhysicalButton(GamepadButton.R1, true, "TestPad")

        assertEquals(0.5f, latest.analogX, 0.001f)
        assertEquals(-0.25f, latest.analogY, 0.001f)
        assertTrue(latest.pressedButtons.contains(GamepadButton.A))
        assertTrue(latest.pressedButtons.contains(GamepadButton.R1))
    }

    @Test
    fun `storage manager initializes base manifest and transitions to ready`() = runTest {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val storage = StorageManager(ctx)
        assertTrue(storage.initializeDefaultManifest())

        val snapshot = storage.inspectEnvironment(null)
        assertEquals(EnvironmentStatus.READY, snapshot.status)
        assertTrue(snapshot.verifiedFiles.any { it.name == StorageManager.ESSENTIAL_MANIFEST })
    }

    @Test
    fun `game scanner installs and discovers playable html5 and storm2d games`() = runTest {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val storage = StorageManager(ctx)
        assertTrue(storage.installSampleGame(null))

        val games = storage.gameScanner.scanAllGames(null, storage.runtimeRootDir)
        assertTrue(games.any { it.type == com.stormcore.launcher.storage.GameType.HTML5_WEB })
        assertTrue(games.any { it.type == com.stormcore.launcher.storage.GameType.STORM_2D })

        val webGame = games.first { it.type == com.stormcore.launcher.storage.GameType.HTML5_WEB }
        val index = storage.gameScanner.buildAssetIndex(webGame)
        assertTrue(index.containsKey("index.html"))
    }

    @Test
    fun `pe inspector parses x86_64 header and game scanner detects pc nwjs web folder`() = runTest {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val storage = StorageManager(ctx)

        // Create a synthetic x86-64 PE header file
        val peFile = java.io.File(ctx.cacheDir, "TestGame.exe")
        val bytes = ByteArray(256)
        bytes[0] = 0x4D // 'M'
        bytes[1] = 0x5A // 'Z'
        bytes[0x3C] = 0x80.toByte() // e_lfanew = 0x80
        bytes[0x80] = 0x50 // 'P'
        bytes[0x81] = 0x45 // 'E'
        bytes[0x84] = 0x64 // Machine 0x8664 (x86-64) LE
        bytes[0x85] = 0x86.toByte()
        bytes[0x98] = 0x0B // PE32+ (0x020B) LE
        bytes[0x99] = 0x02
        peFile.writeBytes(bytes)

        val pe = com.stormcore.launcher.storage.PeExecutableInspector.inspectFile(peFile)
        assertTrue(pe.isValidPe)
        assertEquals("x86-64 (64-bit)", pe.archLabel)
        assertEquals("PE32+ (Win64)", pe.subsystemLabel)

        // Create a PC NW.js / RPG Maker style folder (www/index.html)
        val pcDir = java.io.File(storage.runtimeRootDir, "MyPcRpgGame").apply { mkdirs() }
        val wwwDir = java.io.File(pcDir, "www").apply { mkdirs() }
        java.io.File(wwwDir, "index.html").writeText("<html><body>PC Web Build</body></html>")

        val games = storage.gameScanner.scanAllGames(null, storage.runtimeRootDir)
        assertTrue(games.any { it.type == com.stormcore.launcher.storage.GameType.PC_NWJS_WEB })
    }
}

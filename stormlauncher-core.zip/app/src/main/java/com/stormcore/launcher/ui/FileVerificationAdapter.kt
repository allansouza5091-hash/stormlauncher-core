package com.stormcore.launcher.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.R
import com.example.databinding.ItemVerifiedFileBinding
import com.stormcore.launcher.storage.VerifiedFileInfo
import java.util.Locale

class FileVerificationAdapter :
    ListAdapter<VerifiedFileInfo, FileVerificationAdapter.FileViewHolder>(DiffCallback) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FileViewHolder {
        val binding = ItemVerifiedFileBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return FileViewHolder(binding)
    }

    override fun onBindViewHolder(holder: FileViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class FileViewHolder(
        private val binding: ItemVerifiedFileBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(item: VerifiedFileInfo) {
            val ctx = binding.root.context
            binding.tvFileName.text = item.name
            val sizeText = formatBytes(item.sizeBytes)
            binding.tvFileMeta.text = "${item.sourceLabel} • ${item.relativePath} • $sizeText"
            binding.tvFileHash.text = if (item.sha256Short == "DIR") {
                "PASTA"
            } else {
                "SHA256:${item.sha256Short}"
            }
            val nameColor = if (item.isEssential) R.color.storm_accent_gold else R.color.storm_text_primary
            binding.tvFileName.setTextColor(ContextCompat.getColor(ctx, nameColor))
        }

        private fun formatBytes(bytes: Long): String = when {
            bytes <= 0L -> "—"
            bytes < 1024L -> "$bytes B"
            bytes < 1024L * 1024L -> String.format(Locale.US, "%.1f KB", bytes / 1024f)
            else -> String.format(Locale.US, "%.2f MB", bytes / (1024f * 1024f))
        }
    }

    private object DiffCallback : DiffUtil.ItemCallback<VerifiedFileInfo>() {
        override fun areItemsTheSame(oldItem: VerifiedFileInfo, newItem: VerifiedFileInfo): Boolean =
            oldItem.relativePath == newItem.relativePath

        override fun areContentsTheSame(oldItem: VerifiedFileInfo, newItem: VerifiedFileInfo): Boolean =
            oldItem == newItem
    }
}

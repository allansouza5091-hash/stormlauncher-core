package com.stormcore.launcher.controls

enum class GamepadButton(val id: String, val label: String) {
    A("A", "A"),
    B("B", "B"),
    X("X", "X"),
    Y("Y", "Y"),
    L1("L1", "L1"),
    R1("R1", "R1"),
    START("START", "START"),
    SELECT("SELECT", "SELECT"),
    DPAD_UP("DPAD_UP", "UP"),
    DPAD_DOWN("DPAD_DOWN", "DOWN"),
    DPAD_LEFT("DPAD_LEFT", "LEFT"),
    DPAD_RIGHT("DPAD_RIGHT", "RIGHT")
}

data class InputState(
    val analogX: Float = 0f,
    val analogY: Float = 0f,
    val rightStickX: Float = 0f,
    val rightStickY: Float = 0f,
    val pressedButtons: Set<GamepadButton> = emptySet(),
    val activeSource: String = "Inativo"
) {
    fun formatSummary(): String {
        val btnStr = if (pressedButtons.isEmpty()) "—" else pressedButtons.joinToString("+") { it.label }
        return String.format(
            java.util.Locale.US,
            "L:(%+.2f,%+.2f)  BTN:[%s]  (%s)",
            analogX,
            analogY,
            btnStr,
            activeSource
        )
    }
}

interface ControllerInputListener {
    fun onInputStateChanged(state: InputState)
    fun onButtonEvent(button: GamepadButton, pressed: Boolean, source: String) {}
}

/**
 * Combines simultaneous virtual overlay touch inputs and physical Bluetooth/USB gamepad inputs
 * into a single deterministic [InputState] stream.
 */
class UnifiedInputHub(private val listener: ControllerInputListener) {

    private var virtualAnalogX = 0f
    private var virtualAnalogY = 0f
    private var virtualButtons = emptySet<GamepadButton>()

    private var physicalAnalogX = 0f
    private var physicalAnalogY = 0f
    private var physicalRightX = 0f
    private var physicalRightY = 0f
    private var physicalButtons = emptySet<GamepadButton>()
    private var physicalHatButtons = emptySet<GamepadButton>()
    private var lastSource = "Inativo"

    fun updateVirtualAnalog(dx: Float, dy: Float) {
        virtualAnalogX = dx
        virtualAnalogY = dy
        if (kotlin.math.abs(dx) > 0.01f || kotlin.math.abs(dy) > 0.01f) {
            lastSource = "Virtual"
        }
        dispatchMerged()
    }

    fun updateVirtualButtons(buttons: Set<GamepadButton>, changedButton: GamepadButton?, pressed: Boolean) {
        virtualButtons = buttons
        if (changedButton != null) {
            lastSource = "Virtual"
            listener.onButtonEvent(changedButton, pressed, "Virtual")
        }
        dispatchMerged()
    }

    fun updatePhysicalAxes(lx: Float, ly: Float, rx: Float, ry: Float, hatButtons: Set<GamepadButton>, deviceName: String) {
        physicalAnalogX = lx
        physicalAnalogY = ly
        physicalRightX = rx
        physicalRightY = ry
        physicalHatButtons = hatButtons
        lastSource = deviceName
        dispatchMerged()
    }

    fun updatePhysicalButton(button: GamepadButton, pressed: Boolean, deviceName: String) {
        val next = physicalButtons.toMutableSet()
        val changed = if (pressed) next.add(button) else next.remove(button)
        if (changed) {
            physicalButtons = next
            lastSource = deviceName
            listener.onButtonEvent(button, pressed, deviceName)
            dispatchMerged()
        }
    }

    private fun dispatchMerged() {
        val usePhysicalLeft = kotlin.math.hypot(physicalAnalogX.toDouble(), physicalAnalogY.toDouble()) >=
            kotlin.math.hypot(virtualAnalogX.toDouble(), virtualAnalogY.toDouble())
        val mergedX = if (usePhysicalLeft) physicalAnalogX else virtualAnalogX
        val mergedY = if (usePhysicalLeft) physicalAnalogY else virtualAnalogY
        val mergedButtons = virtualButtons + physicalButtons + physicalHatButtons

        listener.onInputStateChanged(
            InputState(
                analogX = mergedX,
                analogY = mergedY,
                rightStickX = physicalRightX,
                rightStickY = physicalRightY,
                pressedButtons = mergedButtons,
                activeSource = if (mergedButtons.isEmpty() && mergedX == 0f && mergedY == 0f) "Inativo" else lastSource
            )
        )
    }
}

package com.stormcore.launcher.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.databinding.FragmentControlsBinding
import java.util.Locale
import kotlinx.coroutines.launch

class ControlsFragment : Fragment() {

    private var _binding: FragmentControlsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()
    private var suppressSync = false

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentControlsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.switchVirtualControls.setOnCheckedChangeListener { _, checked ->
            if (!suppressSync) viewModel.setVirtualControlsEnabled(checked)
        }

        binding.switchFloatingAnalog.setOnCheckedChangeListener { _, checked ->
            if (!suppressSync) viewModel.setFloatingAnalog(checked)
        }

        binding.sliderOpacity.addOnChangeListener { _, value, fromUser ->
            if (fromUser) viewModel.setControlsOpacity(value.toInt())
        }

        binding.sliderScale.addOnChangeListener { _, value, fromUser ->
            if (fromUser) viewModel.setControlsScale(value.toInt())
        }

        binding.sliderDeadzone.addOnChangeListener { _, value, fromUser ->
            if (fromUser) viewModel.setAnalogDeadzone(value / 100f)
        }

        binding.btnOpenHudEditor.setOnClickListener {
            startActivity(Intent(requireContext(), HudEditorActivity::class.java))
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.config.collect { cfg ->
                        suppressSync = true
                        binding.switchVirtualControls.isChecked = cfg.virtualControlsEnabled
                        binding.switchFloatingAnalog.isChecked = cfg.floatingAnalog
                        binding.sliderOpacity.value = cfg.controlsOpacityPercent.toFloat().coerceIn(10f, 100f)
                        binding.sliderScale.value = cfg.controlsScalePercent.toFloat().coerceIn(70f, 140f)
                        val dzPercent = (cfg.analogDeadzone * 100f).toInt().coerceIn(4, 36)
                        binding.sliderDeadzone.value = dzPercent.toFloat()

                        binding.tvOpacityValue.text = "${cfg.controlsOpacityPercent}%"
                        binding.tvScaleValue.text = "${cfg.controlsScalePercent}%"
                        binding.tvDeadzoneValue.text = "${dzPercent}%"
                        suppressSync = false
                    }
                }
                launch {
                    viewModel.connectedGamepads.collect { devices ->
                        binding.tvConnectedGamepads.text = if (devices.isEmpty()) {
                            "Nenhum gamepad físico conectado. Conecte via USB-C ou Bluetooth."
                        } else {
                            devices.joinToString("\n") { dev ->
                                "• ${dev.name}  (ID=${dev.deviceId}, VID=0x${dev.vendorId.toString(16)}, PID=0x${dev.productId.toString(16)})"
                            }
                        }
                    }
                }
                launch {
                    viewModel.testerInputState.collect { input ->
                        binding.tvTesterAxes.text = String.format(
                            Locale.US,
                            "LX: %+.2f  LY: %+.2f  |  RX: %+.2f  RY: %+.2f",
                            input.analogX,
                            input.analogY,
                            input.rightStickX,
                            input.rightStickY
                        )
                        val btns = if (input.pressedButtons.isEmpty()) {
                            "Nenhum"
                        } else {
                            input.pressedButtons.joinToString(" + ") { it.label }
                        }
                        binding.tvTesterButtons.text = "Pressionado: [$btns] (${input.activeSource})"
                    }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

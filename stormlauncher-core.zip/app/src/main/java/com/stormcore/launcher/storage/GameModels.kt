package com.stormcore.launcher.storage

enum class GameType(val badge: String, val isPlayable: Boolean) {
    HTML5_WEB("HTML5 / WebGL", true),
    PC_NWJS_WEB("PC Web / RPG Maker", true),
    STORM_2D("Storm2D Cartridge", true),
    GLSL_SHADER("Shader GLSL ES3", true),
    PC_NATIVE_UNSUPPORTED("PC Win32/x64 (.exe)", false),
    UNSUPPORTED("Formato Externo", false)
}

data class GameEntry(
    val id: String,
    val title: String,
    val type: GameType,
    val sourceLabel: String,
    val rootPathOrUri: String,
    val entryPathOrUri: String,
    val isSafSource: Boolean,
    val fileCount: Int,
    val description: String
)

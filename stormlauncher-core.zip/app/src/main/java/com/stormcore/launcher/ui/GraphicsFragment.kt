package com.stormcore.launcher.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.R
import com.example.databinding.FragmentGraphicsBinding
import com.stormcore.launcher.config.FpsLimit
import com.stormcore.launcher.config.ResolutionScale
import com.stormcore.launcher.config.ShaderFilter
import kotlinx.coroutines.launch

class GraphicsFragment : Fragment() {

    private var _binding: FragmentGraphicsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()
    private var suppressSync = false

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentGraphicsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.toggleResolutionScale.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked || suppressSync) return@addOnButtonCheckedListener
            val scale = when (checkedId) {
                R.id.btnScale05 -> ResolutionScale.SCALE_0_5
                R.id.btnScale075 -> ResolutionScale.SCALE_0_75
                R.id.btnScale125 -> ResolutionScale.SCALE_1_25
                else -> ResolutionScale.SCALE_1_0
            }
            viewModel.setResolutionScale(scale)
        }

        binding.toggleFpsLimit.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked || suppressSync) return@addOnButtonCheckedListener
            val limit = when (checkedId) {
                R.id.btnFps30 -> FpsLimit.FPS_30
                R.id.btnFpsUnlimited -> FpsLimit.UNLIMITED
                else -> FpsLimit.FPS_60
            }
            viewModel.setFpsLimit(limit)
        }

        binding.toggleShaderFilter.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked || suppressSync) return@addOnButtonCheckedListener
            val filter = when (checkedId) {
                R.id.btnShaderSharpen -> ShaderFilter.SHARPEN
                R.id.btnShaderCel -> ShaderFilter.CEL_SHADING
                R.id.btnShaderVibrant -> ShaderFilter.VIBRANT
                else -> ShaderFilter.NONE
            }
            viewModel.setShaderFilter(filter)
        }

        binding.switchVsync.setOnCheckedChangeListener { _, isChecked ->
            if (!suppressSync) viewModel.setVsync(isChecked)
        }

        binding.switchShowFps.setOnCheckedChangeListener { _, isChecked ->
            if (!suppressSync) viewModel.setShowFpsCounter(isChecked)
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.config.collect { cfg ->
                    suppressSync = true
                    val scaleId = when (cfg.resolutionScale) {
                        ResolutionScale.SCALE_0_5 -> R.id.btnScale05
                        ResolutionScale.SCALE_0_75 -> R.id.btnScale075
                        ResolutionScale.SCALE_1_0 -> R.id.btnScale10
                        ResolutionScale.SCALE_1_25 -> R.id.btnScale125
                    }
                    if (binding.toggleResolutionScale.checkedButtonId != scaleId) {
                        binding.toggleResolutionScale.check(scaleId)
                    }

                    val fpsId = when (cfg.fpsLimit) {
                        FpsLimit.FPS_30 -> R.id.btnFps30
                        FpsLimit.FPS_60 -> R.id.btnFps60
                        FpsLimit.UNLIMITED -> R.id.btnFpsUnlimited
                    }
                    if (binding.toggleFpsLimit.checkedButtonId != fpsId) {
                        binding.toggleFpsLimit.check(fpsId)
                    }

                    val shaderId = when (cfg.shaderFilter) {
                        ShaderFilter.NONE -> R.id.btnShaderNone
                        ShaderFilter.SHARPEN -> R.id.btnShaderSharpen
                        ShaderFilter.CEL_SHADING -> R.id.btnShaderCel
                        ShaderFilter.VIBRANT -> R.id.btnShaderVibrant
                    }
                    if (binding.toggleShaderFilter.checkedButtonId != shaderId) {
                        binding.toggleShaderFilter.check(shaderId)
                    }

                    binding.tvShaderDescription.text = cfg.shaderFilter.description
                    binding.switchVsync.isChecked = cfg.vsyncEnabled
                    binding.switchShowFps.isChecked = cfg.showFpsCounter
                    suppressSync = false
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

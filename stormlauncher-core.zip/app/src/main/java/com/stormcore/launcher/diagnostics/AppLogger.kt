package com.stormcore.launcher.diagnostics

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class LogLevel(val label: String) {
    INFO("INFO"),
    SHADER("GLSL"),
    STORAGE("SAF/IO"),
    INPUT("INPUT"),
    WARN("WARN"),
    ERROR("ERROR")
}

data class LogEntry(
    val id: Long,
    val timestamp: String,
    val level: LogLevel,
    val tag: String,
    val message: String
) {
    fun formatLine(): String = "[$timestamp] [${level.label}] [$tag] $message"
}

object AppLogger {
    private const val MAX_LOG_ENTRIES = 600
    private val lock = Any()
    private var nextId = 1L
    private val timeFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    private val _logs = MutableStateFlow<List<LogEntry>>(emptyList())
    val logs: StateFlow<List<LogEntry>> = _logs.asStateFlow()

    fun i(tag: String, message: String) = append(LogLevel.INFO, tag, message)

    fun shader(tag: String, message: String) = append(LogLevel.SHADER, tag, message)

    fun storage(tag: String, message: String) = append(LogLevel.STORAGE, tag, message)

    fun input(tag: String, message: String) = append(LogLevel.INPUT, tag, message)

    fun w(tag: String, message: String) = append(LogLevel.WARN, tag, message)

    fun e(tag: String, message: String) = append(LogLevel.ERROR, tag, message)

    private fun append(level: LogLevel, tag: String, message: String) {
        val entry = synchronized(lock) {
            val timestamp = timeFormat.format(Date())
            LogEntry(
                id = nextId++,
                timestamp = timestamp,
                level = level,
                tag = tag,
                message = message
            )
        }
        synchronized(lock) {
            val updated = (_logs.value + entry).let { list ->
                if (list.size > MAX_LOG_ENTRIES) list.drop(list.size - MAX_LOG_ENTRIES) else list
            }
            _logs.value = updated
        }
    }

    fun clear() {
        synchronized(lock) {
            _logs.value = emptyList()
        }
        i("Console", "Buffer de logs limpo pelo usuário.")
    }

    fun exportText(): String {
        return _logs.value.joinToString(separator = "\n") { it.formatLine() }
    }
}

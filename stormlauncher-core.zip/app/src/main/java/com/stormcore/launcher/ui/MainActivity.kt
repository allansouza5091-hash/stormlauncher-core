package com.stormcore.launcher.ui

import android.content.res.ColorStateList
import android.os.Bundle
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.R
import com.example.databinding.ActivityMainBinding
import com.stormcore.launcher.config.EnvironmentStatus
import com.stormcore.launcher.controls.ControllerInputListener
import com.stormcore.launcher.controls.GamepadHandler
import com.stormcore.launcher.controls.InputState
import com.stormcore.launcher.controls.UnifiedInputHub
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()

    private lateinit var inputHub: UnifiedInputHub
    private lateinit var gamepadHandler: GamepadHandler

    private enum class HubTab { PLAY, STORAGE, GRAPHICS, CONTROLS, CONSOLE }

    private var activeTab: HubTab = HubTab.PLAY

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        SystemUiHelper.enableImmersiveSticky(this)

        setupGamepadMonitoring()
        setupNavigationRail()
        observeHubState()

        if (savedInstanceState == null) {
            selectTab(HubTab.PLAY)
        }
    }

    override fun onResume() {
        super.onResume()
        SystemUiHelper.enableImmersiveSticky(this)
        viewModel.refreshHardwareTelemetry()
        viewModel.refreshStorageSnapshot()
        viewModel.reloadConfigFromDisk()
        gamepadHandler.register()
    }

    override fun onPause() {
        super.onPause()
        gamepadHandler.unregister()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            SystemUiHelper.enableImmersiveSticky(this)
        }
    }

    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if (gamepadHandler.handleGenericMotionEvent(event)) {
            return true
        }
        return super.onGenericMotionEvent(event)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (gamepadHandler.handleKeyDown(keyCode, event)) {
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (gamepadHandler.handleKeyUp(keyCode, event)) {
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    private fun setupGamepadMonitoring() {
        inputHub = UnifiedInputHub(object : ControllerInputListener {
            override fun onInputStateChanged(state: InputState) {
                viewModel.updateTesterInput(state)
            }
        })
        gamepadHandler = GamepadHandler(
            context = this,
            inputHub = inputHub,
            onDevicesChanged = { devices ->
                viewModel.updateConnectedGamepads(devices)
            }
        )
    }

    private fun setupNavigationRail() {
        binding.navPlay.setOnClickListener { selectTab(HubTab.PLAY) }
        binding.navStorage.setOnClickListener { selectTab(HubTab.STORAGE) }
        binding.navGraphics.setOnClickListener { selectTab(HubTab.GRAPHICS) }
        binding.navControls.setOnClickListener { selectTab(HubTab.CONTROLS) }
        binding.navConsole.setOnClickListener { selectTab(HubTab.CONSOLE) }
    }

    private fun selectTab(tab: HubTab) {
        activeTab = tab
        val navMap = mapOf(
            HubTab.PLAY to binding.navPlay,
            HubTab.STORAGE to binding.navStorage,
            HubTab.GRAPHICS to binding.navGraphics,
            HubTab.CONTROLS to binding.navControls,
            HubTab.CONSOLE to binding.navConsole
        )
        navMap.forEach { (key, view) ->
            view.isSelected = (key == tab)
        }

        val fragment: Fragment = when (tab) {
            HubTab.PLAY -> PlayFragment()
            HubTab.STORAGE -> StorageFragment()
            HubTab.GRAPHICS -> GraphicsFragment()
            HubTab.CONTROLS -> ControlsFragment()
            HubTab.CONSOLE -> ConsoleFragment()
        }
        supportFragmentManager.beginTransaction()
            .replace(R.id.panelContainer, fragment)
            .commit()
    }

    private fun observeHubState() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.hardwareInfo.collect { hw ->
                        binding.tvHardwareSoc.text = "${hw.socName} (${hw.cpuCores}c)"
                        binding.tvHardwareAbi.text = hw.primaryAbi
                        binding.tvHardwareRam.text = "${hw.availableRamMb}/${hw.totalRamMb} MB"
                        binding.tvHardwareGpu.text = hw.gpuRenderer
                    }
                }
                launch {
                    viewModel.storageSnapshot.collect { snapshot ->
                        val status = snapshot?.status ?: EnvironmentStatus.PENDING
                        updateStatusBadge(status)
                    }
                }
                launch {
                    viewModel.config.collect { cfg ->
                        gamepadHandler.customDeadzone = cfg.analogDeadzone
                    }
                }
            }
        }
    }

    private fun updateStatusBadge(status: EnvironmentStatus) {
        binding.tvEnvironmentStatus.text = status.label
        val (textColorRes, bgColorRes) = when (status) {
            EnvironmentStatus.READY -> R.color.storm_status_ready to R.color.storm_status_ready_bg
            EnvironmentStatus.CONFIGURED -> R.color.storm_status_configured to R.color.storm_status_configured_bg
            EnvironmentStatus.PENDING -> R.color.storm_status_pending to R.color.storm_status_pending_bg
        }
        binding.tvEnvironmentStatus.setTextColor(ContextCompat.getColor(this, textColorRes))
        binding.tvEnvironmentStatus.backgroundTintList =
            ColorStateList.valueOf(ContextCompat.getColor(this, bgColorRes))
    }
}

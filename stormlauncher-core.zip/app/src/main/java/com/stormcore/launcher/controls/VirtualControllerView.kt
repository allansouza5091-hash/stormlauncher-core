package com.stormcore.launcher.controls

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import com.stormcore.launcher.config.HudElementPos
import com.stormcore.launcher.config.LauncherConfig
import kotlin.math.hypot
import kotlin.math.min

class VirtualControllerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var inputHub: UnifiedInputHub? = null
    var onHudPositionsChanged: ((Map<String, HudElementPos>) -> Unit)? = null
    var onEditElementSelected: ((HudElementPos) -> Unit)? = null

    private var hudPositions: MutableMap<String, HudElementPos> =
        LauncherConfig.defaultHudPositions().toMutableMap()

    var isEditMode: Boolean = false
        set(value) {
            field = value
            resetTouchState()
            invalidate()
        }

    var floatingAnalog: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    var analogDeadzone: Float = 0.12f
    private var overlayAlpha: Int = 190
    private var scaleFactor: Float = 1.0f

    // Multi-touch pointer tracking
    private var analogPointerId: Int = MotionEvent.INVALID_POINTER_ID
    private var analogOriginX: Float = 0f
    private var analogOriginY: Float = 0f
    private var analogThumbX: Float = 0f
    private var analogThumbY: Float = 0f
    private var analogVecX: Float = 0f
    private var analogVecY: Float = 0f

    private val buttonPointerMap = mutableMapOf<Int, GamepadButton>()
    private val activeButtons = mutableSetOf<GamepadButton>()

    // HUD Edit Mode drag tracking
    private var editingPointerId: Int = MotionEvent.INVALID_POINTER_ID
    private var draggingElementId: String? = null
    private var dragOffsetX: Float = 0f
    private var dragOffsetY: Float = 0f

    // Pre-allocated Paints & Rects (zero allocations during onDraw)
    private val baseFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(120, 18, 24, 38)
    }
    private val activeFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(175, 255, 140, 26)
    }
    private val cyanStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3.2f
        color = Color.rgb(0, 229, 255)
    }
    private val orangeStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3.5f
        color = Color.rgb(255, 140, 26)
    }
    private val analogThumbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(220, 0, 229, 255)
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
        color = Color.argb(70, 0, 229, 255)
        pathEffect = DashPathEffect(floatArrayOf(12f, 10f), 0f)
    }
    private val editHighlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3.5f
        color = Color.rgb(255, 179, 0)
        pathEffect = DashPathEffect(floatArrayOf(10f, 8f), 0f)
    }
    private val tempRect = RectF()

    fun applyConfig(config: LauncherConfig) {
        hudPositions = config.hudPositions.toMutableMap()
        floatingAnalog = config.floatingAnalog
        analogDeadzone = config.analogDeadzone
        overlayAlpha = ((config.controlsOpacityPercent.coerceIn(10, 100) / 100f) * 255f).toInt()
        scaleFactor = (config.controlsScalePercent.coerceIn(70, 140) / 100f)
        invalidate()
    }

    fun getHudPositionsSnapshot(): Map<String, HudElementPos> = hudPositions.toMap()

    fun setHudPositionsSnapshot(positions: Map<String, HudElementPos>) {
        hudPositions = positions.toMutableMap()
        invalidate()
    }

    private fun baseUnit(): Float = min(width, height).coerceAtLeast(360) * scaleFactor

    private fun analogOuterRadius(): Float = baseUnit() * 0.145f
    private fun analogThumbRadius(): Float = baseUnit() * 0.058f
    private fun actionRadius(): Float = baseUnit() * 0.068f
    private fun shoulderHalfW(): Float = baseUnit() * 0.088f
    private fun shoulderHalfH(): Float = baseUnit() * 0.044f
    private fun metaHalfW(): Float = baseUnit() * 0.072f
    private fun metaHalfH(): Float = baseUnit() * 0.034f

    private fun centerX(id: String): Float = (hudPositions[id]?.xPercent ?: 0.5f) * width
    private fun centerY(id: String): Float = (hudPositions[id]?.yPercent ?: 0.5f) * height

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width == 0 || height == 0) return

        val effectiveAlpha = if (isEditMode) 235 else overlayAlpha
        baseFillPaint.alpha = (effectiveAlpha * 0.52f).toInt()
        activeFillPaint.alpha = (effectiveAlpha * 0.88f).toInt()
        cyanStrokePaint.alpha = effectiveAlpha
        orangeStrokePaint.alpha = effectiveAlpha
        analogThumbPaint.alpha = effectiveAlpha
        labelPaint.alpha = effectiveAlpha

        if (isEditMode) {
            drawEditorGrid(canvas)
        }

        drawAnalog(canvas)
        drawFaceButton(canvas, LauncherConfig.HUD_A, GamepadButton.A, useOrange = false)
        drawFaceButton(canvas, LauncherConfig.HUD_B, GamepadButton.B, useOrange = true)
        drawFaceButton(canvas, LauncherConfig.HUD_X, GamepadButton.X, useOrange = false)
        drawFaceButton(canvas, LauncherConfig.HUD_Y, GamepadButton.Y, useOrange = true)

        drawPillButton(canvas, LauncherConfig.HUD_L1, GamepadButton.L1, shoulderHalfW(), shoulderHalfH())
        drawPillButton(canvas, LauncherConfig.HUD_R1, GamepadButton.R1, shoulderHalfW(), shoulderHalfH())
        drawPillButton(canvas, LauncherConfig.HUD_SELECT, GamepadButton.SELECT, metaHalfW(), metaHalfH())
        drawPillButton(canvas, LauncherConfig.HUD_START, GamepadButton.START, metaHalfW(), metaHalfH())
    }

    private fun drawEditorGrid(canvas: Canvas) {
        val cols = 8
        val rows = 5
        for (i in 1 until cols) {
            val x = width * (i / cols.toFloat())
            canvas.drawLine(x, 0f, x, height.toFloat(), gridPaint)
        }
        for (j in 1 until rows) {
            val y = height * (j / rows.toFloat())
            canvas.drawLine(0f, y, width.toFloat(), y, gridPaint)
        }
    }

    private fun drawAnalog(canvas: Canvas) {
        val cx = if (analogPointerId != MotionEvent.INVALID_POINTER_ID && floatingAnalog) {
            analogOriginX
        } else {
            centerX(LauncherConfig.HUD_ANALOG)
        }
        val cy = if (analogPointerId != MotionEvent.INVALID_POINTER_ID && floatingAnalog) {
            analogOriginY
        } else {
            centerY(LauncherConfig.HUD_ANALOG)
        }
        val outerR = analogOuterRadius()
        val thumbR = analogThumbRadius()

        canvas.drawCircle(cx, cy, outerR, baseFillPaint)
        canvas.drawCircle(cx, cy, outerR, cyanStrokePaint)

        // Subtle inner crosshairs
        canvas.drawCircle(cx, cy, outerR * analogDeadzone, gridPaint)

        val tx = if (analogPointerId != MotionEvent.INVALID_POINTER_ID) analogThumbX else cx
        val ty = if (analogPointerId != MotionEvent.INVALID_POINTER_ID) analogThumbY else cy
        canvas.drawCircle(tx, ty, thumbR, analogThumbPaint)
        canvas.drawCircle(tx, ty, thumbR, orangeStrokePaint)

        if (isEditMode) {
            val stroke = if (draggingElementId == LauncherConfig.HUD_ANALOG) editHighlightPaint else gridPaint
            canvas.drawCircle(cx, cy, outerR + 10f, stroke)
        }
    }

    private fun drawFaceButton(
        canvas: Canvas,
        id: String,
        button: GamepadButton,
        useOrange: Boolean
    ) {
        val cx = centerX(id)
        val cy = centerY(id)
        val r = actionRadius()
        val pressed = activeButtons.contains(button)

        canvas.drawCircle(cx, cy, r, if (pressed) activeFillPaint else baseFillPaint)
        canvas.drawCircle(cx, cy, r, if (useOrange) orangeStrokePaint else cyanStrokePaint)

        labelPaint.textSize = r * 0.72f
        val textY = cy - (labelPaint.descent() + labelPaint.ascent()) / 2f
        canvas.drawText(button.label, cx, textY, labelPaint)

        if (isEditMode && draggingElementId == id) {
            canvas.drawCircle(cx, cy, r + 10f, editHighlightPaint)
        }
    }

    private fun drawPillButton(
        canvas: Canvas,
        id: String,
        button: GamepadButton,
        halfW: Float,
        halfH: Float
    ) {
        val cx = centerX(id)
        val cy = centerY(id)
        val pressed = activeButtons.contains(button)
        tempRect.set(cx - halfW, cy - halfH, cx + halfW, cy + halfH)

        val corner = halfH * 0.75f
        canvas.drawRoundRect(tempRect, corner, corner, if (pressed) activeFillPaint else baseFillPaint)
        canvas.drawRoundRect(tempRect, corner, corner, cyanStrokePaint)

        labelPaint.textSize = halfH * 0.85f
        val textY = cy - (labelPaint.descent() + labelPaint.ascent()) / 2f
        canvas.drawText(button.label, cx, textY, labelPaint)

        if (isEditMode && draggingElementId == id) {
            tempRect.inset(-8f, -8f)
            canvas.drawRoundRect(tempRect, corner + 6f, corner + 6f, editHighlightPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (isEditMode) {
            return handleEditTouch(event)
        }
        return handlePlayTouch(event)
    }

    private fun handleEditTouch(event: MotionEvent): Boolean {
        val action = event.actionMasked
        val idx = event.actionIndex
        val pointerId = event.getPointerId(idx)

        when (action) {
            MotionEvent.ACTION_DOWN -> {
                val x = event.getX(idx)
                val y = event.getY(idx)
                val hitId = findHitElementId(x, y)
                if (hitId != null) {
                    editingPointerId = pointerId
                    draggingElementId = hitId
                    dragOffsetX = centerX(hitId) - x
                    dragOffsetY = centerY(hitId) - y
                    performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    hudPositions[hitId]?.let { onEditElementSelected?.invoke(it) }
                    invalidate()
                    return true
                }
            }

            MotionEvent.ACTION_MOVE -> {
                val activeId = draggingElementId ?: return false
                val pIdx = event.findPointerIndex(editingPointerId)
                if (pIdx < 0) return false
                val newX = (event.getX(pIdx) + dragOffsetX).coerceIn(width * 0.05f, width * 0.95f)
                val newY = (event.getY(pIdx) + dragOffsetY).coerceIn(height * 0.08f, height * 0.94f)
                val prev = hudPositions[activeId] ?: return false
                val updated = prev.copy(
                    xPercent = (newX / width.coerceAtLeast(1)).coerceIn(0.05f, 0.95f),
                    yPercent = (newY / height.coerceAtLeast(1)).coerceIn(0.08f, 0.94f)
                )
                hudPositions[activeId] = updated
                onEditElementSelected?.invoke(updated)
                onHudPositionsChanged?.invoke(hudPositions.toMap())
                invalidate()
                return true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                draggingElementId = null
                editingPointerId = MotionEvent.INVALID_POINTER_ID
                invalidate()
                return true
            }
        }
        return true
    }

    private fun handlePlayTouch(event: MotionEvent): Boolean {
        val action = event.actionMasked
        val idx = event.actionIndex
        val pointerId = event.getPointerId(idx)

        when (action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val x = event.getX(idx)
                val y = event.getY(idx)
                val hitButton = findHitButton(x, y)
                if (hitButton != null) {
                    buttonPointerMap[pointerId] = hitButton
                    if (activeButtons.add(hitButton)) {
                        performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                        inputHub?.updateVirtualButtons(activeButtons.toSet(), hitButton, true)
                    }
                    invalidate()
                    return true
                }

                if (analogPointerId == MotionEvent.INVALID_POINTER_ID && isAnalogZone(x, y)) {
                    analogPointerId = pointerId
                    if (floatingAnalog) {
                        analogOriginX = x
                        analogOriginY = y
                    } else {
                        analogOriginX = centerX(LauncherConfig.HUD_ANALOG)
                        analogOriginY = centerY(LauncherConfig.HUD_ANALOG)
                    }
                    performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    updateAnalogFromTouch(x, y)
                    invalidate()
                    return true
                }
            }

            MotionEvent.ACTION_MOVE -> {
                var needsRedraw = false
                for (i in 0 until event.pointerCount) {
                    val pid = event.getPointerId(i)
                    val px = event.getX(i)
                    val py = event.getY(i)
                    if (pid == analogPointerId) {
                        updateAnalogFromTouch(px, py)
                        needsRedraw = true
                    } else if (buttonPointerMap.containsKey(pid)) {
                        val oldBtn = buttonPointerMap[pid]
                        val newBtn = findHitButton(px, py)
                        if (newBtn != oldBtn) {
                            if (oldBtn != null && activeButtons.remove(oldBtn)) {
                                inputHub?.updateVirtualButtons(activeButtons.toSet(), oldBtn, false)
                            }
                            if (newBtn != null) {
                                buttonPointerMap[pid] = newBtn
                                if (activeButtons.add(newBtn)) {
                                    performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                                    inputHub?.updateVirtualButtons(activeButtons.toSet(), newBtn, true)
                                }
                            } else {
                                buttonPointerMap.remove(pid)
                            }
                            needsRedraw = true
                        }
                    }
                }
                if (needsRedraw) invalidate()
                return true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                if (action == MotionEvent.ACTION_CANCEL) {
                    resetTouchState()
                    invalidate()
                    return true
                }
                if (pointerId == analogPointerId) {
                    analogPointerId = MotionEvent.INVALID_POINTER_ID
                    analogVecX = 0f
                    analogVecY = 0f
                    inputHub?.updateVirtualAnalog(0f, 0f)
                    invalidate()
                    return true
                }
                val releasedBtn = buttonPointerMap.remove(pointerId)
                if (releasedBtn != null) {
                    val stillHeld = buttonPointerMap.values.contains(releasedBtn)
                    if (!stillHeld && activeButtons.remove(releasedBtn)) {
                        inputHub?.updateVirtualButtons(activeButtons.toSet(), releasedBtn, false)
                    }
                    invalidate()
                    return true
                }
            }
        }
        return false
    }

    private fun updateAnalogFromTouch(touchX: Float, touchY: Float) {
        val maxDist = analogOuterRadius()
        val dx = touchX - analogOriginX
        val dy = touchY - analogOriginY
        val dist = hypot(dx.toDouble(), dy.toDouble()).toFloat()

        val clampedDist = dist.coerceAtMost(maxDist)
        val angle = kotlin.math.atan2(dy.toDouble(), dx.toDouble())
        analogThumbX = analogOriginX + (clampedDist * kotlin.math.cos(angle)).toFloat()
        analogThumbY = analogOriginY + (clampedDist * kotlin.math.sin(angle)).toFloat()

        val rawNorm = (clampedDist / maxDist).coerceIn(0f, 1f)
        if (rawNorm <= analogDeadzone) {
            analogVecX = 0f
            analogVecY = 0f
        } else {
            val rescaled = ((rawNorm - analogDeadzone) / (1f - analogDeadzone)).coerceIn(0f, 1f)
            analogVecX = (rescaled * kotlin.math.cos(angle)).toFloat().coerceIn(-1f, 1f)
            analogVecY = (rescaled * kotlin.math.sin(angle)).toFloat().coerceIn(-1f, 1f)
        }
        inputHub?.updateVirtualAnalog(analogVecX, analogVecY)
    }

    private fun isAnalogZone(x: Float, y: Float): Boolean {
        val cx = centerX(LauncherConfig.HUD_ANALOG)
        val cy = centerY(LauncherConfig.HUD_ANALOG)
        val dist = hypot((x - cx).toDouble(), (y - cy).toDouble()).toFloat()
        return if (floatingAnalog) {
            x < width * 0.48f && y > height * 0.28f
        } else {
            dist <= analogOuterRadius() * 1.45f
        }
    }

    private fun findHitButton(x: Float, y: Float): GamepadButton? {
        val faceHitR = actionRadius() * 1.25f
        val facePairs = listOf(
            LauncherConfig.HUD_A to GamepadButton.A,
            LauncherConfig.HUD_B to GamepadButton.B,
            LauncherConfig.HUD_X to GamepadButton.X,
            LauncherConfig.HUD_Y to GamepadButton.Y
        )
        for ((id, btn) in facePairs) {
            if (hypot((x - centerX(id)).toDouble(), (y - centerY(id)).toDouble()) <= faceHitR) {
                return btn
            }
        }

        val shoulderPairs = listOf(
            LauncherConfig.HUD_L1 to GamepadButton.L1,
            LauncherConfig.HUD_R1 to GamepadButton.R1
        )
        for ((id, btn) in shoulderPairs) {
            val cx = centerX(id)
            val cy = centerY(id)
            if (kotlin.math.abs(x - cx) <= shoulderHalfW() * 1.15f &&
                kotlin.math.abs(y - cy) <= shoulderHalfH() * 1.35f
            ) {
                return btn
            }
        }

        val metaPairs = listOf(
            LauncherConfig.HUD_SELECT to GamepadButton.SELECT,
            LauncherConfig.HUD_START to GamepadButton.START
        )
        for ((id, btn) in metaPairs) {
            val cx = centerX(id)
            val cy = centerY(id)
            if (kotlin.math.abs(x - cx) <= metaHalfW() * 1.15f &&
                kotlin.math.abs(y - cy) <= metaHalfH() * 1.35f
            ) {
                return btn
            }
        }
        return null
    }

    private fun findHitElementId(x: Float, y: Float): String? {
        findHitButton(x, y)?.let { return it.id }
        val cx = centerX(LauncherConfig.HUD_ANALOG)
        val cy = centerY(LauncherConfig.HUD_ANALOG)
        if (hypot((x - cx).toDouble(), (y - cy).toDouble()) <= analogOuterRadius() * 1.25f) {
            return LauncherConfig.HUD_ANALOG
        }
        return null
    }

    private fun resetTouchState() {
        analogPointerId = MotionEvent.INVALID_POINTER_ID
        analogVecX = 0f
        analogVecY = 0f
        buttonPointerMap.clear()
        val prevButtons = activeButtons.toList()
        activeButtons.clear()
        prevButtons.forEach { btn ->
            inputHub?.updateVirtualButtons(emptySet(), btn, false)
        }
        inputHub?.updateVirtualAnalog(0f, 0f)
    }
}

package com.stormcore.launcher.ui

import android.net.Uri
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import com.stormcore.launcher.config.ShaderFilter
import com.stormcore.launcher.controls.GamepadButton
import com.stormcore.launcher.controls.InputState
import com.stormcore.launcher.diagnostics.AppLogger
import com.stormcore.launcher.storage.GameScanner
import java.io.ByteArrayInputStream
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject

class SafWebGameClient(
    private val gameScanner: GameScanner,
    private val assetIndex: Map<String, Uri>,
    private val entryFileName: String,
    private val initialShaderFilter: ShaderFilter
) : WebViewClient() {

    private var lastButtons = emptySet<GamepadButton>()
    private var lastAxesKey = ""

    override fun shouldInterceptRequest(
        view: WebView?,
        request: WebResourceRequest?
    ): WebResourceResponse? {
        val url = request?.url ?: return null
        if (url.host != VIRTUAL_HOST) {
            return super.shouldInterceptRequest(view, request)
        }

        val rawPath = url.path?.trimStart('/')?.takeIf { it.isNotBlank() } ?: entryFileName
        val safePath = sanitizeRelativePath(rawPath)
        val uri = assetIndex[safePath.lowercase()]
            ?: assetIndex[entryFileName.lowercase()].takeIf { safePath.equals("index.html", ignoreCase = true) }

        if (uri == null) {
            return WebResourceResponse(
                "text/plain",
                "UTF-8",
                404,
                "Not Found",
                CORS_HEADERS,
                ByteArrayInputStream("Asset not found: $safePath".toByteArray())
            )
        }

        val stream = gameScanner.openAssetStream(uri) ?: return WebResourceResponse(
            "text/plain",
            "UTF-8",
            500,
            "Read Error",
            CORS_HEADERS,
            ByteArrayInputStream("Failed to open asset: $safePath".toByteArray())
        )

        val mime = guessMimeType(safePath)
        val encoding = if (mime.startsWith("text/") || mime == "application/javascript" || mime == "application/json") {
            "UTF-8"
        } else {
            null
        }
        return WebResourceResponse(mime, encoding, 200, "OK", CORS_HEADERS, stream)
    }

    override fun onPageFinished(view: WebView?, url: String?) {
        super.onPageFinished(view, url)
        view?.let { webView ->
            webView.evaluateJavascript(GAMEPAD_SHIM_JS, null)
            applyShaderFilter(webView, initialShaderFilter)
            AppLogger.i("WebRuntime", "Jogo Web carregado e ponte StormInput + Gamepad API injetada.")
        }
    }

    fun applyShaderFilter(webView: WebView, filter: ShaderFilter) {
        val cssFilter = when (filter) {
            ShaderFilter.NONE -> "none"
            ShaderFilter.SHARPEN -> "contrast(1.14) brightness(1.03)"
            ShaderFilter.CEL_SHADING -> "contrast(1.38) saturate(1.25)"
            ShaderFilter.VIBRANT -> "contrast(1.22) saturate(1.48) brightness(1.05)"
        }
        webView.evaluateJavascript(
            "document.documentElement.style.filter = '$cssFilter';",
            null
        )
    }

    fun pushInputToWebGame(webView: WebView, state: InputState) {
        val currentButtons = state.pressedButtons
        val axesKey = String.format(Locale.US, "%.2f,%.2f", state.analogX, state.analogY)
        if (currentButtons == lastButtons && axesKey == lastAxesKey) return

        val newlyPressed = currentButtons - lastButtons
        val newlyReleased = lastButtons - currentButtons
        lastButtons = currentButtons
        lastAxesKey = axesKey

        val btnArray = JSONArray().apply {
            currentButtons.forEach { put(it.id) }
        }
        val payload = JSONObject().apply {
            put("lx", state.analogX.toDouble())
            put("ly", state.analogY.toDouble())
            put("rx", state.rightStickX.toDouble())
            put("ry", state.rightStickY.toDouble())
            put("buttons", btnArray)
        }

        val sb = StringBuilder()
        sb.append("window.__stormUpdateInput && window.__stormUpdateInput(")
        sb.append(payload.toString())
        sb.append(");")

        newlyPressed.forEach { btn ->
            val keyCode = mapButtonToJsKey(btn)
            if (keyCode != null) {
                sb.append("window.__stormKey('keydown','${keyCode.first}','${keyCode.second}',${keyCode.third});")
            }
        }
        newlyReleased.forEach { btn ->
            val keyCode = mapButtonToJsKey(btn)
            if (keyCode != null) {
                sb.append("window.__stormKey('keyup','${keyCode.first}','${keyCode.second}',${keyCode.third});")
            }
        }

        webView.evaluateJavascript(sb.toString(), null)
    }

    private fun mapButtonToJsKey(btn: GamepadButton): Triple<String, String, Int>? = when (btn) {
        GamepadButton.A -> Triple(" ", "Space", 32)
        GamepadButton.B -> Triple("x", "KeyX", 88)
        GamepadButton.X -> Triple("c", "KeyC", 67)
        GamepadButton.Y -> Triple("v", "KeyV", 86)
        GamepadButton.L1 -> Triple("q", "KeyQ", 81)
        GamepadButton.R1 -> Triple("e", "KeyE", 69)
        GamepadButton.START -> Triple("Enter", "Enter", 13)
        GamepadButton.SELECT -> Triple("Tab", "Tab", 9)
        GamepadButton.DPAD_UP -> Triple("ArrowUp", "ArrowUp", 38)
        GamepadButton.DPAD_DOWN -> Triple("ArrowDown", "ArrowDown", 40)
        GamepadButton.DPAD_LEFT -> Triple("ArrowLeft", "ArrowLeft", 37)
        GamepadButton.DPAD_RIGHT -> Triple("ArrowRight", "ArrowRight", 39)
    }

    private fun sanitizeRelativePath(path: String): String {
        val segments = path.split('/').filter { it.isNotEmpty() && it != "." && it != ".." }
        return segments.joinToString("/")
    }

    private fun guessMimeType(path: String): String {
        val ext = path.substringAfterLast('.', "").lowercase(Locale.US)
        return when (ext) {
            "html", "htm" -> "text/html"
            "js", "mjs" -> "application/javascript"
            "css" -> "text/css"
            "json" -> "application/json"
            "wasm" -> "application/wasm"
            "png" -> "image/png"
            "jpg", "jpeg" -> "image/jpeg"
            "gif" -> "image/gif"
            "webp" -> "image/webp"
            "svg" -> "image/svg+xml"
            "mp3" -> "audio/mpeg"
            "ogg" -> "audio/ogg"
            "wav" -> "audio/wav"
            "woff2" -> "font/woff2"
            "woff" -> "font/woff"
            "ttf" -> "font/ttf"
            else -> "application/octet-stream"
        }
    }

    companion object {
        const val VIRTUAL_HOST = "appassets.stormcore.local"

        fun entryUrl(entryFileName: String): String =
            "https://$VIRTUAL_HOST/${entryFileName.trimStart('/')}"

        fun configureWebView(webView: WebView) {
            webView.settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                mediaPlaybackRequiresUserGesture = false
                useWideViewPort = true
                loadWithOverviewMode = true
                allowFileAccess = false
                allowContentAccess = false
                cacheMode = WebSettings.LOAD_NO_CACHE
            }
            webView.webChromeClient = WebChromeClient()
        }

        private val CORS_HEADERS = mapOf(
            "Access-Control-Allow-Origin" to "*",
            "Cross-Origin-Opener-Policy" to "same-origin",
            "Cross-Origin-Embedder-Policy" to "require-corp"
        )

        private val GAMEPAD_SHIM_JS = """
            (function() {
              if (window.__stormBridgeReady) return;
              window.__stormBridgeReady = true;
              window.StormInput = { lx: 0, ly: 0, rx: 0, ry: 0, buttons: [] };
              const btnOrder = ['A','B','X','Y','L1','R1','SELECT','START','DPAD_UP','DPAD_DOWN','DPAD_LEFT','DPAD_RIGHT'];
              let virtualPad = {
                id: 'StormLauncher Virtual Gamepad',
                index: 0,
                connected: true,
                mapping: 'standard',
                axes: [0, 0, 0, 0],
                buttons: btnOrder.map(() => ({ pressed: false, touched: false, value: 0 })),
                timestamp: performance.now()
              };
              const origGetGamepads = navigator.getGamepads ? navigator.getGamepads.bind(navigator) : null;
              navigator.getGamepads = function() {
                const pads = origGetGamepads ? Array.from(origGetGamepads()) : [null, null, null, null];
                pads[0] = virtualPad;
                return pads;
              };
              window.__stormKey = function(type, key, code, keyCode) {
                const ev = new KeyboardEvent(type, { key, code, keyCode, which: keyCode, bubbles: true, cancelable: true });
                window.dispatchEvent(ev);
                document.dispatchEvent(ev);
              };
              window.__stormUpdateInput = function(state) {
                window.StormInput = state;
                const set = new Set(state.buttons || []);
                virtualPad.axes = [state.lx || 0, state.ly || 0, state.rx || 0, state.ry || 0];
                virtualPad.buttons = btnOrder.map(id => {
                  const p = set.has(id);
                  return { pressed: p, touched: p, value: p ? 1.0 : 0.0 };
                });
                virtualPad.timestamp = performance.now();
              };
            })();
        """.trimIndent()
    }
}

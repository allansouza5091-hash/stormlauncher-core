package com.stormcore.launcher.graphics

import android.content.Context
import android.opengl.GLSurfaceView
import android.util.AttributeSet
import com.stormcore.launcher.config.LauncherConfig
import com.stormcore.launcher.controls.InputState

class StormGLSurfaceView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : GLSurfaceView(context, attrs) {

    private var stormRenderer: StormRenderer? = null

    init {
        setEGLContextClientVersion(3)
        setEGLConfigChooser(8, 8, 8, 8, 0, 0)
        preserveEGLContextOnPause = true
    }

    fun attachRenderer(
        initialConfig: LauncherConfig,
        customFragmentShader: String? = null,
        onFpsUpdated: (Float) -> Unit,
        onGpuInfoReady: (renderer: String, vendor: String, version: String) -> Unit
    ) {
        if (stormRenderer != null) return
        val renderer = StormRenderer(
            initialConfig = initialConfig,
            customFragmentShader = customFragmentShader,
            onFpsUpdated = onFpsUpdated,
            onGpuInfoReady = onGpuInfoReady
        )
        stormRenderer = renderer
        setRenderer(renderer)
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    fun updateConfig(config: LauncherConfig) {
        stormRenderer?.updateConfig(config)
    }

    fun updateInput(state: InputState) {
        stormRenderer?.updateInput(state)
    }

    fun setPaused(paused: Boolean) {
        stormRenderer?.isPaused = paused
    }

    fun releaseRenderer() {
        queueEvent {
            stormRenderer?.release()
        }
    }
}

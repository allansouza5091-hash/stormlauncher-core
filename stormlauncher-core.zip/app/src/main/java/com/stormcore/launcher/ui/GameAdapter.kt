package com.stormcore.launcher.ui

import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.R
import com.example.databinding.ItemGameEntryBinding
import com.stormcore.launcher.storage.GameEntry
import com.stormcore.launcher.storage.GameType

class GameAdapter(
    private val onGameSelected: (GameEntry) -> Unit
) : ListAdapter<GameEntry, GameAdapter.GameViewHolder>(DiffCallback) {

    var selectedGameId: String? = null
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GameViewHolder {
        val binding = ItemGameEntryBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return GameViewHolder(binding)
    }

    override fun onBindViewHolder(holder: GameViewHolder, position: Int) {
        val item = getItem(position)
        holder.bind(item, item.id == selectedGameId, onGameSelected)
    }

    class GameViewHolder(
        private val binding: ItemGameEntryBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(
            item: GameEntry,
            isSelected: Boolean,
            onGameSelected: (GameEntry) -> Unit
        ) {
            val ctx = binding.root.context
            binding.tvGameTitle.text = item.title
            binding.tvGameTypeBadge.text = "${item.type.badge} • ${item.sourceLabel}"
            binding.tvGameDescription.text = item.description

            val (badgeText, badgeBg) = when (item.type) {
                GameType.HTML5_WEB -> R.color.storm_accent_cyan to R.color.storm_accent_cyan_dim
                GameType.PC_NWJS_WEB -> R.color.storm_accent_cyan to R.color.storm_accent_cyan_dim
                GameType.STORM_2D -> R.color.storm_status_ready to R.color.storm_status_ready_bg
                GameType.GLSL_SHADER -> R.color.storm_accent_gold to R.color.storm_accent_orange_dim
                GameType.PC_NATIVE_UNSUPPORTED -> R.color.storm_status_error to R.color.storm_status_error_bg
                GameType.UNSUPPORTED -> R.color.storm_status_pending to R.color.storm_status_pending_bg
            }
            binding.tvGameTypeBadge.setTextColor(ContextCompat.getColor(ctx, badgeText))
            binding.tvGameTypeBadge.backgroundTintList =
                ColorStateList.valueOf(ContextCompat.getColor(ctx, badgeBg))

            binding.cardGameRoot.strokeColor = ContextCompat.getColor(
                ctx,
                if (isSelected) R.color.storm_accent_orange else R.color.storm_outline
            )
            binding.cardGameRoot.strokeWidth = if (isSelected) 3 else 1
            binding.tvGameSelectedTag.visibility = if (isSelected) View.VISIBLE else View.GONE

            binding.cardGameRoot.setOnClickListener {
                onGameSelected(item)
            }
        }
    }

    private object DiffCallback : DiffUtil.ItemCallback<GameEntry>() {
        override fun areItemsTheSame(oldItem: GameEntry, newItem: GameEntry): Boolean =
            oldItem.id == newItem.id

        override fun areContentsTheSame(oldItem: GameEntry, newItem: GameEntry): Boolean =
            oldItem == newItem
    }
}

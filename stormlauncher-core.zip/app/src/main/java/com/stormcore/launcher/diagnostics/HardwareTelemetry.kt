package com.stormcore.launcher.diagnostics

import android.app.ActivityManager
import android.content.Context
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.GLES30
import android.os.Build

data class HardwareInfo(
    val socName: String,
    val cpuCores: Int,
    val primaryAbi: String,
    val supportedAbis: String,
    val totalRamMb: Long,
    val availableRamMb: Long,
    val gpuRenderer: String,
    val gpuVendor: String,
    val glesVersion: String,
    val androidVersion: String
)

object HardwareTelemetry {

    @Volatile
    private var cachedGpuRenderer: String = ""

    @Volatile
    private var cachedGpuVendor: String = ""

    @Volatile
    private var cachedGlesVersion: String = ""

    fun updateGpuInfo(renderer: String, vendor: String, version: String) {
        if (renderer.isNotBlank()) cachedGpuRenderer = renderer
        if (vendor.isNotBlank()) cachedGpuVendor = vendor
        if (version.isNotBlank()) cachedGlesVersion = version
    }

    fun collect(context: Context): HardwareInfo {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memInfo)

        val totalRamMb = memInfo.totalMem / (1024L * 1024L)
        val availRamMb = memInfo.availMem / (1024L * 1024L)

        val socModel = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            Build.SOC_MODEL.takeIf { it.isNotBlank() && it != Build.UNKNOWN }
        } else {
            null
        }
        val socName = socModel ?: "${Build.MANUFACTURER} ${Build.HARDWARE}".trim()
        val abis = Build.SUPPORTED_ABIS.toList()
        val primaryAbi = abis.firstOrNull() ?: "unknown"

        if (cachedGpuRenderer.isBlank()) {
            probeOpenGlEs30()
        }

        return HardwareInfo(
            socName = socName,
            cpuCores = Runtime.getRuntime().availableProcessors(),
            primaryAbi = primaryAbi,
            supportedAbis = abis.joinToString(", "),
            totalRamMb = totalRamMb,
            availableRamMb = availRamMb,
            gpuRenderer = cachedGpuRenderer.ifBlank { "OpenGL ES 3.0 GPU" },
            gpuVendor = cachedGpuVendor.ifBlank { "Hardware" },
            glesVersion = cachedGlesVersion.ifBlank { "OpenGL ES 3.0" },
            androidVersion = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
        )
    }

    private fun probeOpenGlEs30() {
        var display = EGL14.EGL_NO_DISPLAY
        var context = EGL14.EGL_NO_CONTEXT
        var surface = EGL14.EGL_NO_SURFACE
        try {
            display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
            if (display == EGL14.EGL_NO_DISPLAY) return

            val version = IntArray(2)
            if (!EGL14.eglInitialize(display, version, 0, version, 1)) return

            val configAttribs = intArrayOf(
                EGL14.EGL_RENDERABLE_TYPE, 0x00000040, // EGL_OPENGL_ES3_BIT_KHR
                EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT,
                EGL14.EGL_RED_SIZE, 8,
                EGL14.EGL_GREEN_SIZE, 8,
                EGL14.EGL_BLUE_SIZE, 8,
                EGL14.EGL_ALPHA_SIZE, 8,
                EGL14.EGL_NONE
            )
            val configs = arrayOfNulls<EGLConfig>(1)
            val numConfigs = IntArray(1)
            if (!EGL14.eglChooseConfig(display, configAttribs, 0, configs, 0, 1, numConfigs, 0) ||
                numConfigs[0] <= 0 || configs[0] == null
            ) {
                return
            }

            val contextAttribs = intArrayOf(
                EGL14.EGL_CONTEXT_CLIENT_VERSION, 3,
                EGL14.EGL_NONE
            )
            context = EGL14.eglCreateContext(display, configs[0], EGL14.EGL_NO_CONTEXT, contextAttribs, 0)
            if (context == EGL14.EGL_NO_CONTEXT) return

            val surfaceAttribs = intArrayOf(
                EGL14.EGL_WIDTH, 1,
                EGL14.EGL_HEIGHT, 1,
                EGL14.EGL_NONE
            )
            surface = EGL14.eglCreatePbufferSurface(display, configs[0], surfaceAttribs, 0)
            if (surface == EGL14.EGL_NO_SURFACE) return

            if (EGL14.eglMakeCurrent(display, surface, surface, context)) {
                cachedGpuRenderer = GLES30.glGetString(GLES30.GL_RENDERER).orEmpty()
                cachedGpuVendor = GLES30.glGetString(GLES30.GL_VENDOR).orEmpty()
                cachedGlesVersion = GLES30.glGetString(GLES30.GL_VERSION).orEmpty()
                AppLogger.i(
                    "Telemetry",
                    "Probe GPU concluído: $cachedGpuRenderer ($cachedGpuVendor) | $cachedGlesVersion"
                )
            }
        } catch (t: Throwable) {
            AppLogger.w("Telemetry", "Probe EGL14 indisponível no boot: ${t.message}")
        } finally {
            if (display != EGL14.EGL_NO_DISPLAY) {
                EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                if (surface != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(display, surface)
                if (context != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(display, context)
                EGL14.eglTerminate(display)
            }
        }
    }
}

package com.stormcore.launcher.ui

import android.net.Uri
import android.os.Bundle
import android.view.Choreographer
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.lifecycleScope
import com.example.R
import com.example.databinding.ActivityGameRuntimeBinding
import com.stormcore.launcher.config.ConfigRepository
import com.stormcore.launcher.config.LauncherConfig
import com.stormcore.launcher.config.ShaderFilter
import com.stormcore.launcher.controls.ControllerInputListener
import com.stormcore.launcher.controls.GamepadButton
import com.stormcore.launcher.controls.GamepadHandler
import com.stormcore.launcher.controls.InputState
import com.stormcore.launcher.controls.UnifiedInputHub
import com.stormcore.launcher.diagnostics.AppLogger
import com.stormcore.launcher.storage.GameEntry
import com.stormcore.launcher.storage.GameScanner
import com.stormcore.launcher.storage.GameType
import java.io.File
import java.util.Locale
import kotlinx.coroutines.launch

class GameRuntimeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGameRuntimeBinding
    private lateinit var configRepository: ConfigRepository
    private lateinit var currentConfig: LauncherConfig
    private lateinit var inputHub: UnifiedInputHub
    private lateinit var gamepadHandler: GamepadHandler
    private lateinit var gameScanner: GameScanner

    private var activeGameType: GameType = GameType.GLSL_SHADER
    private var activeGameTitle: String = "StormEnergyScene"
    private var webGameClient: SafWebGameClient? = null
    private var isRuntimePaused = false
    private var isOverlayVisible = true

    // Choreographer FPS sampler for HTML5 WebView mode
    private var webFpsActive = false
    private var webFrameCount = 0
    private var webSampleStartNs = 0L
    private val webFpsCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!webFpsActive) return
            webFrameCount++
            if (webSampleStartNs == 0L) webSampleStartNs = frameTimeNanos
            val elapsed = frameTimeNanos - webSampleStartNs
            if (elapsed >= 350_000_000L) {
                val fps = (webFrameCount * 1_000_000_000.0 / elapsed).toFloat()
                binding.tvRuntimeFps.text = String.format(Locale.US, "%.1f FPS", fps)
                webFrameCount = 0
                webSampleStartNs = frameTimeNanos
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGameRuntimeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        SystemUiHelper.enableImmersiveSticky(this)

        configRepository = ConfigRepository(this)
        currentConfig = configRepository.config.value
        isOverlayVisible = currentConfig.virtualControlsEnabled
        gameScanner = GameScanner(this)

        setupInputSystem()
        setupHudAndQuickMenu()
        launchConfiguredTarget()
    }

    override fun onResume() {
        super.onResume()
        SystemUiHelper.enableImmersiveSticky(this)
        if (activeGameType == GameType.GLSL_SHADER) {
            binding.glSurfaceView.onResume()
        } else if (activeGameType == GameType.STORM_2D) {
            binding.arcadeGameView.startLoop()
        } else if (activeGameType == GameType.HTML5_WEB || activeGameType == GameType.PC_NWJS_WEB) {
            binding.webGameView.onResume()
            startWebFpsCounter()
        }
        gamepadHandler.register()
    }

    override fun onPause() {
        super.onPause()
        if (activeGameType == GameType.GLSL_SHADER) {
            binding.glSurfaceView.onPause()
        } else if (activeGameType == GameType.STORM_2D) {
            binding.arcadeGameView.stopLoop()
        } else if (activeGameType == GameType.HTML5_WEB || activeGameType == GameType.PC_NWJS_WEB) {
            stopWebFpsCounter()
            binding.webGameView.onPause()
        }
        gamepadHandler.unregister()
    }

    override fun onDestroy() {
        stopWebFpsCounter()
        binding.arcadeGameView.stopLoop()
        binding.glSurfaceView.releaseRenderer()
        binding.webGameView.destroy()
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) SystemUiHelper.enableImmersiveSticky(this)
    }

    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if (gamepadHandler.handleGenericMotionEvent(event)) return true
        return super.onGenericMotionEvent(event)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_BUTTON_MODE) {
            toggleQuickMenu()
            return true
        }
        if (gamepadHandler.handleKeyDown(keyCode, event)) return true
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (gamepadHandler.handleKeyUp(keyCode, event)) return true
        return super.onKeyUp(keyCode, event)
    }

    private fun setupInputSystem() {
        inputHub = UnifiedInputHub(object : ControllerInputListener {
            override fun onInputStateChanged(state: InputState) {
                when (activeGameType) {
                    GameType.GLSL_SHADER -> binding.glSurfaceView.updateInput(state)
                    GameType.STORM_2D -> binding.arcadeGameView.updateInput(state)
                    GameType.HTML5_WEB, GameType.PC_NWJS_WEB -> runOnUiThread {
                        webGameClient?.pushInputToWebGame(binding.webGameView, state)
                    }
                    else -> Unit
                }
                runOnUiThread {
                    binding.tvRuntimeInputStatus.text = state.formatSummary()
                }
            }

            override fun onButtonEvent(button: GamepadButton, pressed: Boolean, source: String) {
                if (pressed) {
                    AppLogger.input(source, "Botão ${button.label} pressionado")
                }
            }
        })

        binding.virtualControllerView.inputHub = inputHub
        binding.virtualControllerView.applyConfig(currentConfig)

        gamepadHandler = GamepadHandler(
            context = this,
            inputHub = inputHub
        ).apply {
            customDeadzone = currentConfig.analogDeadzone
        }
    }

    private fun launchConfiguredTarget() {
        val typeName = intent.getStringExtra(EXTRA_GAME_TYPE)
        val parsedType = typeName?.let { runCatching { GameType.valueOf(it) }.getOrNull() }
            ?: GameType.GLSL_SHADER

        activeGameTitle = intent.getStringExtra(EXTRA_GAME_TITLE) ?: "StormEnergyScene"
        val rootPathOrUri = intent.getStringExtra(EXTRA_GAME_ROOT)
        val entryPathOrUri = intent.getStringExtra(EXTRA_GAME_ENTRY)
        val isSaf = intent.getBooleanExtra(EXTRA_GAME_IS_SAF, false)

        activeGameType = if (!parsedType.isPlayable || entryPathOrUri.isNullOrBlank()) {
            GameType.GLSL_SHADER
        } else {
            parsedType
        }

        when (activeGameType) {
            GameType.HTML5_WEB, GameType.PC_NWJS_WEB -> startHtml5Game(
                GameEntry(
                    id = "runtime",
                    title = activeGameTitle,
                    type = activeGameType,
                    sourceLabel = if (isSaf) "SAF" else "Interno",
                    rootPathOrUri = rootPathOrUri.orEmpty(),
                    entryPathOrUri = entryPathOrUri.orEmpty(),
                    isSafSource = isSaf,
                    fileCount = 0,
                    description = ""
                )
            )
            GameType.STORM_2D -> startStorm2DCartridge(entryPathOrUri.orEmpty(), isSaf)
            else -> startOpenGlShaderRuntime(entryPathOrUri, isSaf)
        }
        applyRuntimeUiConfig()
    }

    private fun startHtml5Game(game: GameEntry) {
        binding.glSurfaceView.visibility = View.GONE
        binding.arcadeGameView.visibility = View.GONE
        binding.webGameView.visibility = View.VISIBLE

        SafWebGameClient.configureWebView(binding.webGameView)
        lifecycleScope.launch {
            val assetIndex = gameScanner.buildAssetIndex(game)
            val entryName = if (game.isSafSource) {
                DocumentFile.fromSingleUri(this@GameRuntimeActivity, Uri.parse(game.entryPathOrUri))
                    ?.name ?: "index.html"
            } else {
                File(game.entryPathOrUri).name
            }
            val client = SafWebGameClient(
                gameScanner = gameScanner,
                assetIndex = assetIndex,
                entryFileName = entryName,
                initialShaderFilter = currentConfig.shaderFilter
            )
            webGameClient = client
            binding.webGameView.webViewClient = client
            binding.webGameView.loadUrl(SafWebGameClient.entryUrl(entryName))
            startWebFpsCounter()
        }
    }

    private fun startStorm2DCartridge(entryPathOrUri: String, isSaf: Boolean) {
        binding.glSurfaceView.visibility = View.GONE
        binding.webGameView.visibility = View.GONE
        binding.arcadeGameView.visibility = View.VISIBLE

        lifecycleScope.launch {
            val json = gameScanner.readTextContent(entryPathOrUri, isSaf)
            binding.arcadeGameView.configureCartridge(json) { fps ->
                runOnUiThread {
                    binding.tvRuntimeFps.text = String.format(Locale.US, "%.1f FPS", fps)
                }
            }
            binding.arcadeGameView.startLoop()
            AppLogger.i("Storm2D", "Cartucho '$activeGameTitle' iniciado a 60 FPS.")
        }
    }

    private fun startOpenGlShaderRuntime(entryPathOrUri: String?, isSaf: Boolean) {
        binding.webGameView.visibility = View.GONE
        binding.arcadeGameView.visibility = View.GONE
        binding.glSurfaceView.visibility = View.VISIBLE

        lifecycleScope.launch {
            val customShader = if (!entryPathOrUri.isNullOrBlank()) {
                gameScanner.readTextContent(entryPathOrUri, isSaf)
            } else {
                null
            }
            binding.glSurfaceView.attachRenderer(
                initialConfig = currentConfig,
                customFragmentShader = customShader,
                onFpsUpdated = { fps ->
                    runOnUiThread {
                        binding.tvRuntimeFps.text = String.format(Locale.US, "%.1f FPS", fps)
                    }
                },
                onGpuInfoReady = { renderer, _, _ ->
                    runOnUiThread {
                        AppLogger.shader("RuntimeGPU", "Renderizador ativo: $renderer")
                    }
                }
            )
        }
    }

    private fun setupHudAndQuickMenu() {
        binding.btnQuickMenu.setOnClickListener {
            toggleQuickMenu()
        }

        binding.btnMenuResume.setOnClickListener {
            binding.quickMenuOverlay.visibility = View.GONE
            if (isRuntimePaused) {
                setPausedState(false)
            }
        }

        binding.btnMenuTogglePause.setOnClickListener {
            setPausedState(!isRuntimePaused)
        }

        binding.btnMenuToggleOverlay.setOnClickListener {
            isOverlayVisible = !isOverlayVisible
            applyRuntimeUiConfig()
            AppLogger.input("Runtime", "Overlay virtual ${if (isOverlayVisible) "exibido" else "ocultado"}")
        }

        binding.btnMenuCycleShader.setOnClickListener {
            val allFilters = ShaderFilter.entries
            val nextIdx = (allFilters.indexOf(currentConfig.shaderFilter) + 1) % allFilters.size
            val nextFilter = allFilters[nextIdx]
            configRepository.updateConfig { it.copy(shaderFilter = nextFilter) }
            currentConfig = configRepository.config.value

            when (activeGameType) {
                GameType.GLSL_SHADER -> binding.glSurfaceView.updateConfig(currentConfig)
                GameType.HTML5_WEB, GameType.PC_NWJS_WEB -> webGameClient?.applyShaderFilter(binding.webGameView, nextFilter)
                else -> Unit
            }
            applyRuntimeUiConfig()
            AppLogger.shader("Runtime", "Shader alternado ao vivo para: ${nextFilter.label}")
        }

        binding.btnMenuExit.setOnClickListener {
            AppLogger.i("Runtime", "Encerrando '$activeGameTitle' e retornando ao Hub.")
            finish()
        }
    }

    private fun setPausedState(paused: Boolean) {
        isRuntimePaused = paused
        when (activeGameType) {
            GameType.GLSL_SHADER -> binding.glSurfaceView.setPaused(paused)
            GameType.STORM_2D -> binding.arcadeGameView.setPaused(paused)
            GameType.HTML5_WEB, GameType.PC_NWJS_WEB -> if (paused) binding.webGameView.onPause() else binding.webGameView.onResume()
            else -> Unit
        }
        binding.btnMenuTogglePause.text = if (paused) {
            "Retomar Renderização"
        } else {
            getString(R.string.btn_pause_runtime)
        }
        AppLogger.i("Runtime", if (paused) "Execução pausada." else "Execução retomada.")
    }

    private fun toggleQuickMenu() {
        binding.quickMenuOverlay.visibility =
            if (binding.quickMenuOverlay.visibility == View.VISIBLE) View.GONE else View.VISIBLE
    }

    private fun applyRuntimeUiConfig() {
        binding.virtualControllerView.visibility =
            if (isOverlayVisible) View.VISIBLE else View.GONE
        binding.tvRuntimeFps.visibility =
            if (currentConfig.showFpsCounter) View.VISIBLE else View.GONE
        binding.tvRuntimePipeline.text =
            "$activeGameTitle • ${currentConfig.resolutionScale.label} | ${currentConfig.shaderFilter.label}"
    }

    private fun startWebFpsCounter() {
        if (webFpsActive) return
        webFpsActive = true
        webFrameCount = 0
        webSampleStartNs = 0L
        Choreographer.getInstance().postFrameCallback(webFpsCallback)
    }

    private fun stopWebFpsCounter() {
        webFpsActive = false
        Choreographer.getInstance().removeFrameCallback(webFpsCallback)
    }

    companion object {
        const val EXTRA_GAME_TITLE = "extra_game_title"
        const val EXTRA_GAME_TYPE = "extra_game_type"
        const val EXTRA_GAME_ROOT = "extra_game_root"
        const val EXTRA_GAME_ENTRY = "extra_game_entry"
        const val EXTRA_GAME_IS_SAF = "extra_game_is_saf"
    }
}

package com.stormcore.launcher.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.stormcore.launcher.config.ConfigRepository
import com.stormcore.launcher.config.FpsLimit
import com.stormcore.launcher.config.LauncherConfig
import com.stormcore.launcher.config.PerformanceProfile
import com.stormcore.launcher.config.ResolutionScale
import com.stormcore.launcher.config.ShaderFilter
import com.stormcore.launcher.controls.GamepadDeviceInfo
import com.stormcore.launcher.controls.InputState
import com.stormcore.launcher.diagnostics.AppLogger
import com.stormcore.launcher.diagnostics.HardwareInfo
import com.stormcore.launcher.diagnostics.HardwareTelemetry
import com.stormcore.launcher.diagnostics.LogEntry
import com.stormcore.launcher.storage.StorageManager
import com.stormcore.launcher.storage.StorageSnapshot
import com.stormcore.launcher.storage.ZipExtractionProgress
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val configRepository = ConfigRepository(application)
    val storageManager = StorageManager(application)

    val config: StateFlow<LauncherConfig> = configRepository.config
    val logs: StateFlow<List<LogEntry>> = AppLogger.logs

    private val _hardwareInfo = MutableStateFlow(HardwareTelemetry.collect(application))
    val hardwareInfo: StateFlow<HardwareInfo> = _hardwareInfo.asStateFlow()

    private val _storageSnapshot = MutableStateFlow<StorageSnapshot?>(null)
    val storageSnapshot: StateFlow<StorageSnapshot?> = _storageSnapshot.asStateFlow()

    private val _selectedGame = MutableStateFlow<com.stormcore.launcher.storage.GameEntry?>(null)
    val selectedGame: StateFlow<com.stormcore.launcher.storage.GameEntry?> = _selectedGame.asStateFlow()

    private val _zipProgress = MutableStateFlow<ZipExtractionProgress?>(null)
    val zipProgress: StateFlow<ZipExtractionProgress?> = _zipProgress.asStateFlow()

    private val _connectedGamepads = MutableStateFlow<List<GamepadDeviceInfo>>(emptyList())
    val connectedGamepads: StateFlow<List<GamepadDeviceInfo>> = _connectedGamepads.asStateFlow()

    private val _testerInputState = MutableStateFlow(InputState())
    val testerInputState: StateFlow<InputState> = _testerInputState.asStateFlow()

    init {
        AppLogger.i(
            "Core",
            "StormLauncher Core inicializado — ABI: ${_hardwareInfo.value.primaryAbi}, GPU: ${_hardwareInfo.value.gpuRenderer}"
        )
        refreshStorageSnapshot()
    }

    fun refreshHardwareTelemetry() {
        _hardwareInfo.value = HardwareTelemetry.collect(getApplication())
    }

    fun refreshStorageSnapshot(autoExtractZips: Boolean = false) {
        viewModelScope.launch {
            val safUri = config.value.safTreeUri
            if (autoExtractZips && !safUri.isNullOrBlank()) {
                val pendingZips = storageManager.gameScanner.findPendingZipsInSafFolder(
                    safUri,
                    storageManager.runtimeRootDir
                )
                if (pendingZips.isNotEmpty()) {
                    AppLogger.storage(
                        "AutoZIP",
                        "Detectado(s) ${pendingZips.size} arquivo(s) .ZIP na pasta SAF. Extraindo automaticamente..."
                    )
                    for (zip in pendingZips) {
                        val subdir = storageManager.gameScanner.sanitizeZipFolderName(zip.name)
                        storageManager.extractZipFromUri(zip.uri, subdir).collect { progress ->
                            _zipProgress.value = progress
                        }
                    }
                }
            }

            val snap = storageManager.inspectEnvironment(safUri)
            _storageSnapshot.value = snap

            val currentId = _selectedGame.value?.id
            val updatedSelected = snap.detectedGames.firstOrNull { it.id == currentId }
                ?: snap.detectedGames.firstOrNull { it.type.isPlayable }
                ?: snap.detectedGames.firstOrNull()
            _selectedGame.value = updatedSelected
        }
    }

    fun selectGame(game: com.stormcore.launcher.storage.GameEntry) {
        _selectedGame.value = game
        AppLogger.i("Library", "Jogo selecionado: ${game.title} (${game.type.badge})")
    }

    fun onSafFolderSelected(uri: Uri) {
        val label = storageManager.persistSafPermission(uri)
        if (label != null) {
            configRepository.updateConfig { it.copy(safTreeUri = uri.toString()) }
            refreshStorageSnapshot(autoExtractZips = true)
        }
    }

    fun initializeDefaultWorkspace() {
        viewModelScope.launch {
            if (storageManager.initializeDefaultManifest()) {
                refreshStorageSnapshot()
            }
        }
    }

    fun installSampleGameInWorkspace() {
        viewModelScope.launch {
            if (storageManager.installSampleGame(config.value.safTreeUri)) {
                refreshStorageSnapshot()
            }
        }
    }

    fun extractZipPackage(zipUri: Uri) {
        viewModelScope.launch {
            storageManager.extractZipFromUri(zipUri).collect { progress ->
                _zipProgress.value = progress
                if (progress.isFinished) {
                    refreshStorageSnapshot()
                }
            }
        }
    }

    fun setPerformanceProfile(profile: PerformanceProfile) {
        configRepository.updateConfig { it.copy(performanceProfile = profile) }
        AppLogger.i("Config", "Perfil de desempenho definido para: ${profile.displayName}")
    }

    fun setResolutionScale(scale: ResolutionScale) {
        configRepository.updateConfig { it.copy(resolutionScale = scale) }
        AppLogger.shader("Config", "Escala de resolução interna: ${scale.label}")
    }

    fun setFpsLimit(limit: FpsLimit) {
        configRepository.updateConfig { it.copy(fpsLimit = limit) }
        AppLogger.shader("Config", "Limite de FPS ajustado para: ${limit.label}")
    }

    fun setShaderFilter(filter: ShaderFilter) {
        configRepository.updateConfig { it.copy(shaderFilter = filter) }
        AppLogger.shader("Config", "Filtro de pós-processamento: ${filter.label}")
    }

    fun setVsync(enabled: Boolean) {
        configRepository.updateConfig { it.copy(vsyncEnabled = enabled) }
        AppLogger.shader("Config", "V-Sync ${if (enabled) "ativado" else "desativado"}")
    }

    fun setShowFpsCounter(enabled: Boolean) {
        configRepository.updateConfig { it.copy(showFpsCounter = enabled) }
    }

    fun setVirtualControlsEnabled(enabled: Boolean) {
        configRepository.updateConfig { it.copy(virtualControlsEnabled = enabled) }
        AppLogger.input("HUD", "Controles virtuais ${if (enabled) "ativados" else "desativados"}")
    }

    fun setFloatingAnalog(floating: Boolean) {
        configRepository.updateConfig { it.copy(floatingAnalog = floating) }
    }

    fun setControlsOpacity(percent: Int) {
        configRepository.updateConfig { it.copy(controlsOpacityPercent = percent) }
    }

    fun setControlsScale(percent: Int) {
        configRepository.updateConfig { it.copy(controlsScalePercent = percent) }
    }

    fun setAnalogDeadzone(deadzone: Float) {
        configRepository.updateConfig { it.copy(analogDeadzone = deadzone) }
    }

    fun updateConnectedGamepads(devices: List<GamepadDeviceInfo>) {
        _connectedGamepads.value = devices
    }

    fun updateTesterInput(state: InputState) {
        _testerInputState.value = state
    }

    fun reloadConfigFromDisk() {
        val fresh = ConfigRepository(getApplication()).config.value
        configRepository.updateConfig { fresh }
    }
}

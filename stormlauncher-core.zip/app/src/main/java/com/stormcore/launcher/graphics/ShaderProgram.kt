package com.stormcore.launcher.graphics

import android.opengl.GLES30
import com.stormcore.launcher.diagnostics.AppLogger
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

class ShaderProgram(
    private val name: String,
    vertexSource: String,
    fragmentSource: String
) {
    var programId: Int = 0
        private set

    var isValid: Boolean = false
        private set

    private var uResolutionLoc: Int = -1
    private var uTimeLoc: Int = -1
    private var uIntensityLoc: Int = -1
    private var uModeLoc: Int = -1
    private var uInputVecLoc: Int = -1
    private var uActionPulseLoc: Int = -1
    private var uSceneTexLoc: Int = -1

    init {
        compileAndLink(vertexSource, fragmentSource)
    }

    private fun compileAndLink(vertexSource: String, fragmentSource: String) {
        val vertexShader = compileShader(GLES30.GL_VERTEX_SHADER, "Vertex", vertexSource)
        if (vertexShader == 0) return

        val fragmentShader = compileShader(GLES30.GL_FRAGMENT_SHADER, "Fragment", fragmentSource)
        if (fragmentShader == 0) {
            GLES30.glDeleteShader(vertexShader)
            return
        }

        val program = GLES30.glCreateProgram()
        if (program == 0) {
            AppLogger.e("GLSL:$name", "Falha ao alocar objeto GLProgram (glCreateProgram retornou 0).")
            GLES30.glDeleteShader(vertexShader)
            GLES30.glDeleteShader(fragmentShader)
            return
        }

        GLES30.glAttachShader(program, vertexShader)
        GLES30.glAttachShader(program, fragmentShader)
        GLES30.glLinkProgram(program)

        val linkStatus = IntArray(1)
        GLES30.glGetProgramiv(program, GLES30.GL_LINK_STATUS, linkStatus, 0)
        if (linkStatus[0] == 0) {
            val infoLog = GLES30.glGetProgramInfoLog(program)
            AppLogger.e("GLSL:$name", "Erro de linkagem do shader '$name':\n$infoLog")
            GLES30.glDeleteProgram(program)
            GLES30.glDeleteShader(vertexShader)
            GLES30.glDeleteShader(fragmentShader)
            return
        }

        // Shaders are now linked into the program and can be flagged for deletion
        GLES30.glDeleteShader(vertexShader)
        GLES30.glDeleteShader(fragmentShader)

        programId = program
        isValid = true

        uResolutionLoc = GLES30.glGetUniformLocation(programId, "u_Resolution")
        uTimeLoc = GLES30.glGetUniformLocation(programId, "u_Time")
        uIntensityLoc = GLES30.glGetUniformLocation(programId, "u_Intensity")
        uModeLoc = GLES30.glGetUniformLocation(programId, "u_Mode")
        uInputVecLoc = GLES30.glGetUniformLocation(programId, "u_InputVec")
        uActionPulseLoc = GLES30.glGetUniformLocation(programId, "u_ActionPulse")
        uSceneTexLoc = GLES30.glGetUniformLocation(programId, "u_SceneTex")

        AppLogger.shader(
            "GLSL:$name",
            "Programa #version 300 es compilado e linkado (ID=$programId, uniforms ativos)."
        )
    }

    private fun compileShader(type: Int, stageName: String, source: String): Int {
        val shader = GLES30.glCreateShader(type)
        if (shader == 0) {
            AppLogger.e("GLSL:$name", "Falha ao criar shader $stageName.")
            return 0
        }
        GLES30.glShaderSource(shader, source)
        GLES30.glCompileShader(shader)

        val compileStatus = IntArray(1)
        GLES30.glGetShaderiv(shader, GLES30.GL_COMPILE_STATUS, compileStatus, 0)
        val infoLog = GLES30.glGetShaderInfoLog(shader).orEmpty().trim()
        if (compileStatus[0] == 0) {
            AppLogger.e(
                "GLSL:$name",
                "Erro de compilação no $stageName Shader ($name):\n${infoLog.ifEmpty { "Sem detalhes do driver." }}"
            )
            GLES30.glDeleteShader(shader)
            return 0
        }
        if (infoLog.isNotEmpty()) {
            AppLogger.shader("GLSL:$name", "$stageName warnings: $infoLog")
        }
        return shader
    }

    fun use() {
        if (isValid) {
            GLES30.glUseProgram(programId)
        }
    }

    fun setStandardUniforms(
        width: Float,
        height: Float,
        timeSec: Float,
        intensity: Float,
        mode: Int
    ) {
        if (uResolutionLoc >= 0) GLES30.glUniform2f(uResolutionLoc, width, height)
        if (uTimeLoc >= 0) GLES30.glUniform1f(uTimeLoc, timeSec)
        if (uIntensityLoc >= 0) GLES30.glUniform1f(uIntensityLoc, intensity)
        if (uModeLoc >= 0) GLES30.glUniform1i(uModeLoc, mode)
    }

    fun setInteractiveUniforms(inputX: Float, inputY: Float, actionPulse: Float) {
        if (uInputVecLoc >= 0) GLES30.glUniform2f(uInputVecLoc, inputX, inputY)
        if (uActionPulseLoc >= 0) GLES30.glUniform1f(uActionPulseLoc, actionPulse)
    }

    fun bindSceneTexture(textureUnit: Int, textureId: Int) {
        if (uSceneTexLoc >= 0) {
            GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + textureUnit)
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
            GLES30.glUniform1i(uSceneTexLoc, textureUnit)
        }
    }

    fun release() {
        if (programId != 0) {
            GLES30.glDeleteProgram(programId)
            programId = 0
            isValid = false
        }
    }

    companion object {
        // Interleaved X, Y, U, V for full-screen triangle strip quad
        private val QUAD_VERTICES = floatArrayOf(
            -1.0f, -1.0f, 0.0f, 0.0f,
             1.0f, -1.0f, 1.0f, 0.0f,
            -1.0f,  1.0f, 0.0f, 1.0f,
             1.0f,  1.0f, 1.0f, 1.0f
        )

        fun createQuadBuffer(): FloatBuffer =
            ByteBuffer.allocateDirect(QUAD_VERTICES.size * 4)
                .order(ByteOrder.nativeOrder())
                .asFloatBuffer()
                .apply {
                    put(QUAD_VERTICES)
                    position(0)
                }
    }
}

package com.stormcore.launcher.graphics

object StormShaders {

    const val FULLSCREEN_VERTEX_SHADER = """#version 300 es
precision highp float;

layout(location = 0) in vec2 a_Position;
layout(location = 1) in vec2 a_TexCoord;

out vec2 v_Uv;

void main() {
    v_Uv = a_TexCoord;
    gl_Position = vec4(a_Position, 0.0, 1.0);
}
"""

    const val ENERGY_SCENE_FRAGMENT_SHADER = """#version 300 es
precision highp float;

in vec2 v_Uv;
out vec4 fragColor;

uniform vec2 u_Resolution;
uniform float u_Time;
uniform float u_Intensity;
uniform int u_Mode;
uniform vec2 u_InputVec;
uniform float u_ActionPulse;

float hash21(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash21(i);
    float b = hash21(i + vec2(1.0, 0.0));
    float c = hash21(i + vec2(0.0, 1.0));
    float d = hash21(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
    float v = 0.0;
    float amp = 0.5;
    mat2 rot = mat2(0.8, -0.6, 0.6, 0.8);
    for (int i = 0; i < 4; i++) {
        v += amp * noise(p);
        p = rot * p * 2.04 + vec2(1.7, 9.2);
        amp *= 0.5;
    }
    return v;
}

float hexDist(vec2 p) {
    p = abs(p);
    float c = dot(p, normalize(vec2(1.0, 1.73205)));
    return max(c, p.x);
}

void main() {
    vec2 res = max(u_Resolution, vec2(1.0));
    float aspect = res.x / res.y;
    vec2 uv = (v_Uv - 0.5) * vec2(aspect, 1.0);

    // Offset energy center smoothly with virtual/physical analog vector
    vec2 centerOffset = vec2(u_InputVec.x * 0.24, -u_InputVec.y * 0.18);
    vec2 p = uv - centerOffset;

    float t = u_Time * (0.65 + 0.2 * u_Intensity);

    // Deep obsidian anime night sky gradient
    vec3 colObsidian = vec3(0.035, 0.052, 0.095);
    vec3 colDeepBlue = vec3(0.065, 0.110, 0.210);
    vec3 colCyan     = vec3(0.000, 0.898, 1.000);
    vec3 colOrange   = vec3(1.000, 0.549, 0.102);
    vec3 colGold     = vec3(1.000, 0.780, 0.220);

    vec3 color = mix(colObsidian, colDeepBlue, clamp(1.0 - length(uv) * 0.85, 0.0, 1.0));

    // Perspective cyber-hex ground plane on lower half
    if (uv.y < 0.05) {
        float depth = 0.18 / max(0.08 - uv.y, 0.025);
        vec2 gridUv = vec2(uv.x * depth, depth + t * 1.4);
        vec2 r = vec2(1.0, 1.73205);
        vec2 h = r * 0.5;
        vec2 a = mod(gridUv, r) - h;
        vec2 b = mod(gridUv - h, r) - h;
        vec2 gv = dot(a, a) < dot(b, b) ? a : b;
        float edge = smoothstep(0.45, 0.495, hexDist(gv));
        float horizonFade = smoothstep(0.05, -0.35, uv.y) * exp(-depth * 0.08);
        color += colCyan * edge * horizonFade * 0.55 * u_Intensity;
    }

    // Flowing chakra / energy waves
    float n1 = fbm(p * 2.2 + vec2(t * 0.45, -t * 0.30));
    float n2 = fbm(p * 3.1 - vec2(t * 0.35, t * 0.50) + n1 * 1.2);

    float waveA = sin(p.x * 5.2 + n1 * 4.5 - t * 2.1) * 0.5 + 0.5;
    float waveB = cos(p.y * 6.4 + n2 * 4.0 + t * 1.7) * 0.5 + 0.5;

    float ribbonCyan = smoothstep(0.76, 0.99, sin(p.y * 5.5 + p.x * 2.2 + n1 * 5.0 - t * 2.4) * 0.5 + 0.5);
    float ribbonOrange = smoothstep(0.78, 0.995, sin(p.y * 4.8 - p.x * 2.6 + n2 * 4.6 + t * 2.0) * 0.5 + 0.5);

    float dist = length(p);
    float auraHalo = exp(-dist * 2.7) * (0.65 + 0.35 * sin(t * 2.5 + n1 * 3.0));
    float coreSpark = exp(-dist * 11.0);

    // Interactive shockwave ring triggered by button presses
    float ringRadius = fract(t * 0.35) * 0.85;
    float ring = exp(-abs(dist - ringRadius) * 28.0) * (0.25 + u_ActionPulse * 1.35);

    color += colCyan * ribbonCyan * (0.55 * waveA + 0.35) * u_Intensity;
    color += mix(colOrange, colGold, waveB) * ribbonOrange * 0.72 * u_Intensity;
    color += mix(colCyan, colOrange, 0.45 + 0.35 * sin(t)) * auraHalo * 0.55 * u_Intensity;
    color += vec3(1.0, 0.94, 0.82) * coreSpark * (0.85 + u_ActionPulse * 0.8);
    color += mix(colCyan, colGold, 0.5) * ring;

    // Subtle rising energy embers
    vec2 starGrid = fract(uv * 18.0 + vec2(0.0, -t * 0.65)) - 0.5;
    float starId = hash21(floor(uv * 18.0 + vec2(0.0, -t * 0.65)));
    float ember = smoothstep(0.14, 0.02, length(starGrid)) * step(0.87, starId);
    color += mix(colCyan, colGold, fract(starId * 13.7)) * ember * 0.85;

    fragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
"""

    const val POST_PROCESS_FRAGMENT_SHADER = """#version 300 es
precision highp float;

in vec2 v_Uv;
out vec4 fragColor;

uniform sampler2D u_SceneTex;
uniform vec2 u_Resolution;
uniform float u_Time;
uniform float u_Intensity;
uniform int u_Mode;

float luminance(vec3 c) {
    return dot(c, vec3(0.299, 0.587, 0.114));
}

void main() {
    vec2 texel = 1.0 / max(u_Resolution, vec2(1.0));
    vec3 center = texture(u_SceneTex, v_Uv).rgb;

    if (u_Mode == 1) {
        // Mode 1: Nitidez / Sharpen (3x3 convolution)
        vec3 n = texture(u_SceneTex, v_Uv + vec2(0.0, texel.y)).rgb;
        vec3 s = texture(u_SceneTex, v_Uv - vec2(0.0, texel.y)).rgb;
        vec3 e = texture(u_SceneTex, v_Uv + vec2(texel.x, 0.0)).rgb;
        vec3 w = texture(u_SceneTex, v_Uv - vec2(texel.x, 0.0)).rgb;
        float k = 0.85 * u_Intensity;
        vec3 sharpened = center * (1.0 + 4.0 * k) - (n + s + e + w) * k;
        fragColor = vec4(clamp(sharpened, 0.0, 1.0), 1.0);
    } else if (u_Mode == 2) {
        // Mode 2: Cel-Shading / Contorno Sobel
        float lTL = luminance(texture(u_SceneTex, v_Uv + vec2(-texel.x,  texel.y)).rgb);
        float lTC = luminance(texture(u_SceneTex, v_Uv + vec2( 0.0,      texel.y)).rgb);
        float lTR = luminance(texture(u_SceneTex, v_Uv + vec2( texel.x,  texel.y)).rgb);
        float lML = luminance(texture(u_SceneTex, v_Uv + vec2(-texel.x,  0.0)).rgb);
        float lMR = luminance(texture(u_SceneTex, v_Uv + vec2( texel.x,  0.0)).rgb);
        float lBL = luminance(texture(u_SceneTex, v_Uv + vec2(-texel.x, -texel.y)).rgb);
        float lBC = luminance(texture(u_SceneTex, v_Uv + vec2( 0.0,     -texel.y)).rgb);
        float lBR = luminance(texture(u_SceneTex, v_Uv + vec2( texel.x, -texel.y)).rgb);

        float gx = -lTL - 2.0 * lML - lBL + lTR + 2.0 * lMR + lBR;
        float gy = -lTL - 2.0 * lTC - lTR + lBL + 2.0 * lBC + lBR;
        float edge = smoothstep(0.14, 0.36, length(vec2(gx, gy)));

        float bands = 5.0;
        vec3 celColor = floor(center * bands + 0.35) / bands;
        celColor = mix(celColor, vec3(0.02, 0.03, 0.06), edge * 0.88);
        fragColor = vec4(clamp(celColor, 0.0, 1.0), 1.0);
    } else if (u_Mode == 3) {
        // Mode 3: Contraste Vibrante + Aberração sutil
        vec2 offset = (v_Uv - 0.5) * texel * 3.5 * u_Intensity;
        float r = texture(u_SceneTex, v_Uv + offset).r;
        float g = center.g;
        float b = texture(u_SceneTex, v_Uv - offset).b;
        vec3 col = vec3(r, g, b);

        // S-curve contrast + saturation boost
        col = smoothstep(0.03, 0.96, col);
        float luma = luminance(col);
        col = mix(vec3(luma), col, 1.38);

        // Subtle console vignette
        float vig = 1.0 - dot(v_Uv - 0.5, v_Uv - 0.5) * 0.55;
        fragColor = vec4(clamp(col * vig, 0.0, 1.0), 1.0);
    } else {
        // Mode 0: Nenhum (pass-through limpo)
        fragColor = vec4(center, 1.0);
    }
}
"""
}

package com.stormcore.launcher.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.databinding.ActivityHudEditorBinding
import com.stormcore.launcher.config.ConfigRepository
import com.stormcore.launcher.config.HudElementPos
import java.util.Locale

class HudEditorActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHudEditorBinding
    private lateinit var configRepository: ConfigRepository
    private var workingPositions: Map<String, HudElementPos> = emptyMap()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHudEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)
        SystemUiHelper.enableImmersiveSticky(this)

        configRepository = ConfigRepository(this)
        val cfg = configRepository.config.value
        workingPositions = cfg.hudPositions

        binding.editorControllerView.apply {
            applyConfig(cfg)
            isEditMode = true
            onHudPositionsChanged = { updated ->
                workingPositions = updated
            }
            onEditElementSelected = { el ->
                binding.tvHudEditorCoords.text = String.format(
                    Locale.US,
                    "%s -> X: %.1f%%  Y: %.1f%%",
                    el.label,
                    el.xPercent * 100f,
                    el.yPercent * 100f
                )
            }
        }

        binding.btnHudReset.setOnClickListener {
            val defaults = configRepository.resetHudPositions()
            workingPositions = defaults
            binding.editorControllerView.setHudPositionsSnapshot(defaults)
            binding.tvHudEditorCoords.text = "Posições restauradas para o layout padrão."
        }

        binding.btnHudCancel.setOnClickListener {
            finish()
        }

        binding.btnHudSave.setOnClickListener {
            configRepository.saveHudPositions(binding.editorControllerView.getHudPositionsSnapshot())
            finish()
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) SystemUiHelper.enableImmersiveSticky(this)
    }
}

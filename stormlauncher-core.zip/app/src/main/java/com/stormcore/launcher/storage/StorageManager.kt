package com.stormcore.launcher.storage

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.stormcore.launcher.config.EnvironmentStatus
import com.stormcore.launcher.diagnostics.AppLogger
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.zip.ZipInputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext

data class VerifiedFileInfo(
    val name: String,
    val relativePath: String,
    val sizeBytes: Long,
    val sha256Short: String,
    val sourceLabel: String,
    val isEssential: Boolean
)

data class PreflightCheck(
    val title: String,
    val detail: String,
    val passed: Boolean
)

data class StorageSnapshot(
    val safFolderLabel: String?,
    val safUriString: String?,
    val runtimeDirPath: String,
    val verifiedFiles: List<VerifiedFileInfo>,
    val preflightChecks: List<PreflightCheck>,
    val detectedGames: List<GameEntry>,
    val status: EnvironmentStatus
)

data class ZipExtractionProgress(
    val currentFile: String,
    val extractedFilesCount: Int,
    val bytesProcessed: Long,
    val percent: Int,
    val isFinished: Boolean = false,
    val errorMessage: String? = null
)

class StorageManager(private val context: Context) {

    private val appContext = context.applicationContext
    val gameScanner = GameScanner(appContext)
    val runtimeRootDir: File = File(appContext.filesDir, RUNTIME_DIR_NAME).apply {
        if (!exists()) mkdirs()
    }

    fun persistSafPermission(uri: Uri): String? {
        return try {
            val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            appContext.contentResolver.takePersistableUriPermission(uri, flags)
            val doc = DocumentFile.fromTreeUri(appContext, uri)
            val name = doc?.name ?: uri.lastPathSegment ?: uri.toString()
            AppLogger.storage("SAF", "Permissão persistente concedida para pasta: $name ($uri)")
            name
        } catch (e: SecurityException) {
            try {
                appContext.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
                val doc = DocumentFile.fromTreeUri(appContext, uri)
                val name = doc?.name ?: uri.lastPathSegment ?: uri.toString()
                AppLogger.storage("SAF", "Permissão somente leitura concedida para: $name")
                name
            } catch (ex: Exception) {
                AppLogger.e("SAF", "Falha ao persistir permissão SAF: ${ex.message}")
                null
            }
        }
    }

    suspend fun initializeDefaultManifest(): Boolean = withContext(Dispatchers.IO) {
        try {
            if (!runtimeRootDir.exists()) runtimeRootDir.mkdirs()
            val manifestFile = File(runtimeRootDir, ESSENTIAL_MANIFEST)
            val shaderCfgFile = File(runtimeRootDir, ESSENTIAL_SHADER_PROFILE)

            manifestFile.writeText(
                """
                {
                  "engine": "StormLauncher Core GLES3",
                  "version": "1.0.0",
                  "renderBackend": "OpenGL ES 3.0",
                  "shaderTarget": "300 es",
                  "verifiedAt": ${System.currentTimeMillis()}
                }
                """.trimIndent()
            )
            shaderCfgFile.writeText(
                """
                {
                  "pipeline": "dual-pass-fbo",
                  "uniforms": ["u_Resolution", "u_Time", "u_Intensity", "u_Mode"],
                  "filters": ["none", "sharpen", "cel_shading", "vibrant"]
                }
                """.trimIndent()
            )
            AppLogger.storage(
                "Workspace",
                "Manifesto base inicializado em ${runtimeRootDir.absolutePath}"
            )
            true
        } catch (e: Exception) {
            AppLogger.e("Workspace", "Erro ao gravar manifesto base: ${e.message}")
            false
        }
    }

    suspend fun inspectEnvironment(safUriString: String?): StorageSnapshot = withContext(Dispatchers.IO) {
        val verified = mutableListOf<VerifiedFileInfo>()

        // 1. Scan internal extracted runtime directory
        val internalFiles = runtimeRootDir.walkTopDown()
            .filter { it.isFile }
            .sortedBy { it.name }
            .take(64)
            .toList()

        for (file in internalFiles) {
            val rel = file.relativeTo(runtimeRootDir).path
            val hash = computeSha256(file)
            val isEssential = file.name == ESSENTIAL_MANIFEST ||
                file.name == ESSENTIAL_SHADER_PROFILE ||
                file.extension.lowercase() in setOf("glsl", "pak", "bin", "cfg", "json")
            verified.add(
                VerifiedFileInfo(
                    name = file.name,
                    relativePath = "internal/$rel",
                    sizeBytes = file.length(),
                    sha256Short = hash.take(16),
                    sourceLabel = "Interno (filesDir)",
                    isEssential = isEssential
                )
            )
        }

        // 2. Scan SAF root folder if configured
        var safFolderName: String? = null
        var safAccessible = false
        if (!safUriString.isNullOrBlank()) {
            val uri = Uri.parse(safUriString)
            val rootDoc = DocumentFile.fromTreeUri(appContext, uri)
            if (rootDoc != null && rootDoc.exists() && rootDoc.canRead()) {
                safAccessible = true
                safFolderName = rootDoc.name ?: "Pasta SAF"
                val children = rootDoc.listFiles().take(48)
                for (doc in children) {
                    if (doc.isFile) {
                        val docName = doc.name ?: "arquivo"
                        val hash = computeUriSha256(doc.uri)
                        val ext = docName.substringAfterLast('.', "").lowercase()
                        verified.add(
                            VerifiedFileInfo(
                                name = docName,
                                relativePath = "saf/$docName",
                                sizeBytes = doc.length(),
                                sha256Short = hash.take(16),
                                sourceLabel = "SAF",
                                isEssential = ext in setOf("zip", "pak", "bin", "json", "glsl", "cfg")
                            )
                        )
                    } else if (doc.isDirectory) {
                        verified.add(
                            VerifiedFileInfo(
                                name = "${doc.name ?: "dir"}/",
                                relativePath = "saf/${doc.name ?: "dir"}/",
                                sizeBytes = 0L,
                                sha256Short = "DIR",
                                sourceLabel = "SAF Dir",
                                isEssential = false
                            )
                        )
                    }
                }
            } else {
                AppLogger.w("SAF", "Pasta SAF configurada não está mais acessível: $safUriString")
            }
        }

        val detectedGames = gameScanner.scanAllGames(safUriString, runtimeRootDir)
        val playableGamesCount = detectedGames.count { it.type.isPlayable }

        val hasManifest = internalFiles.any { it.name == ESSENTIAL_MANIFEST }
        val hasInternalAssets = internalFiles.isNotEmpty()

        val checks = listOf(
            PreflightCheck(
                title = "Biblioteca de Jogos Detectados",
                detail = if (playableGamesCount > 0) "$playableGamesCount jogo(s) jogável(eis) pronto(s) para iniciar"
                else "Selecione uma pasta SAF com um jogo (HTML5/WebGL, Storm2D ou .glsl) ou instale o demo",
                passed = playableGamesCount > 0
            ),
            PreflightCheck(
                title = "Diretório Interno & Manifesto",
                detail = if (hasManifest || hasInternalAssets) "${internalFiles.size} arquivo(s) em filesDir/storm_runtime"
                else "Execute 'Inicializar Manifesto Base' ou extraia um pacote .ZIP",
                passed = hasManifest || hasInternalAssets
            ),
            PreflightCheck(
                title = "Pasta Raiz SAF",
                detail = if (safAccessible) "Montada: $safFolderName"
                else "Selecione uma pasta de jogos via Storage Access Framework",
                passed = safAccessible
            )
        )

        val status = when {
            playableGamesCount > 0 || (hasManifest && (safAccessible || internalFiles.size >= 2)) -> EnvironmentStatus.READY
            safAccessible || hasInternalAssets -> EnvironmentStatus.CONFIGURED
            else -> EnvironmentStatus.PENDING
        }

        StorageSnapshot(
            safFolderLabel = safFolderName,
            safUriString = safUriString,
            runtimeDirPath = runtimeRootDir.absolutePath,
            verifiedFiles = verified,
            preflightChecks = checks,
            detectedGames = detectedGames,
            status = status
        )
    }

    suspend fun installSampleGame(safUriString: String?): Boolean {
        return gameScanner.installPlayableSampleGame(safUriString, runtimeRootDir)
    }

    fun extractZipFromUri(
        zipUri: Uri,
        targetSubdirName: String? = null
    ): Flow<ZipExtractionProgress> = flow {
        val resolver = appContext.contentResolver
        val doc = DocumentFile.fromSingleUri(appContext, zipUri)
        val totalZipBytes = doc?.length()?.takeIf { it > 0 } ?: -1L
        val zipDisplayName = doc?.name ?: zipUri.lastPathSegment ?: "pacote.zip"

        val extractDir = if (!targetSubdirName.isNullOrBlank()) {
            File(runtimeRootDir, targetSubdirName).apply { if (!exists()) mkdirs() }
        } else {
            val safeName = gameScanner.sanitizeZipFolderName(zipDisplayName)
            File(runtimeRootDir, safeName).apply { if (!exists()) mkdirs() }
        }

        AppLogger.storage("ZIP", "Extraindo '$zipDisplayName' para ${extractDir.absolutePath}")

        var extractedCount = 0
        var compressedBytesRead = 0L
        var lastEmittedPercent = -1

        try {
            val rawStream = resolver.openInputStream(zipUri)
                ?: throw IllegalStateException("Não foi possível abrir o stream do arquivo selecionado.")

            val countingStream = object : BufferedInputStream(rawStream, 16384) {
                override fun read(b: ByteArray, off: Int, len: Int): Int {
                    val read = super.read(b, off, len)
                    if (read > 0) compressedBytesRead += read
                    return read
                }
            }

            ZipInputStream(countingStream).use { zis ->
                val targetCanonical = extractDir.canonicalFile
                val buffer = ByteArray(8192)
                var entry = zis.nextEntry

                while (entry != null) {
                    val outFile = File(extractDir, entry.name)
                    val outCanonical = outFile.canonicalFile
                    if (!outCanonical.path.startsWith(targetCanonical.path + File.separator) &&
                        outCanonical != targetCanonical
                    ) {
                        throw SecurityException("Entrada ZIP inválida bloqueada (Zip Slip): ${entry.name}")
                    }

                    if (entry.isDirectory) {
                        if (!outFile.exists()) outFile.mkdirs()
                    } else {
                        outFile.parentFile?.let { parent ->
                            if (!parent.exists()) parent.mkdirs()
                        }
                        BufferedOutputStream(FileOutputStream(outFile)).use { bos ->
                            var read: Int
                            while (zis.read(buffer).also { read = it } != -1) {
                                bos.write(buffer, 0, read)
                            }
                        }
                        extractedCount++
                    }

                    val percent = if (totalZipBytes > 0L) {
                        ((compressedBytesRead * 100L) / totalZipBytes).toInt().coerceIn(1, 99)
                    } else {
                        ((extractedCount * 10) % 95).coerceAtLeast(5)
                    }

                    if (percent != lastEmittedPercent) {
                        lastEmittedPercent = percent
                        emit(
                            ZipExtractionProgress(
                                currentFile = entry.name,
                                extractedFilesCount = extractedCount,
                                bytesProcessed = compressedBytesRead,
                                percent = percent,
                                isFinished = false
                            )
                        )
                    }

                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }

            File(extractDir, ".storm_extracted").writeText(System.currentTimeMillis().toString())
            AppLogger.storage(
                "ZIP",
                "Extração concluída: $extractedCount arquivo(s) gravados em ${extractDir.name}."
            )
            emit(
                ZipExtractionProgress(
                    currentFile = zipDisplayName,
                    extractedFilesCount = extractedCount,
                    bytesProcessed = compressedBytesRead,
                    percent = 100,
                    isFinished = true
                )
            )
        } catch (e: Exception) {
            AppLogger.e("ZIP", "Falha na extração de '$zipDisplayName': ${e.message}")
            emit(
                ZipExtractionProgress(
                    currentFile = zipDisplayName,
                    extractedFilesCount = extractedCount,
                    bytesProcessed = compressedBytesRead,
                    percent = 0,
                    isFinished = true,
                    errorMessage = e.message ?: "Erro desconhecido durante extração ZIP."
                )
            )
        }
    }.flowOn(Dispatchers.IO)

    private fun computeSha256(file: File): String {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            FileInputStream(file).use { fis ->
                val buffer = ByteArray(8192)
                var read: Int
                while (fis.read(buffer).also { read = it } != -1) {
                    digest.update(buffer, 0, read)
                }
            }
            digest.digest().joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            "ERR_HASH"
        }
    }

    private fun computeUriSha256(uri: Uri): String {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            appContext.contentResolver.openInputStream(uri)?.use { stream ->
                val buffer = ByteArray(8192)
                var total = 0L
                var read: Int
                // Cap hash read for multi-GB SAF archives to keep UI responsive while verifying header+payload
                while (stream.read(buffer).also { read = it } != -1 && total < 4L * 1024L * 1024L) {
                    digest.update(buffer, 0, read)
                    total += read
                }
            } ?: return "UNREADABLE"
            digest.digest().joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            "ERR_SAF"
        }
    }

    companion object {
        const val RUNTIME_DIR_NAME = "storm_runtime"
        const val ESSENTIAL_MANIFEST = "core_manifest.json"
        const val ESSENTIAL_SHADER_PROFILE = "default_shader_config.json"
    }
}

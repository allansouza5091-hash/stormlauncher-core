package com.stormcore.launcher.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.databinding.FragmentStorageBinding
import com.stormcore.launcher.diagnostics.AppLogger
import kotlinx.coroutines.launch

class StorageFragment : Fragment() {

    private var _binding: FragmentStorageBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()
    private val fileAdapter = FileVerificationAdapter()

    private val openSafTreeLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            viewModel.onSafFolderSelected(uri)
        } else {
            AppLogger.w("SAF", "Seleção de pasta raiz cancelada pelo usuário.")
        }
    }

    private val openZipLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            viewModel.extractZipPackage(uri)
        } else {
            AppLogger.w("ZIP", "Seleção de pacote .zip cancelada pelo usuário.")
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentStorageBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rvVerifiedFiles.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = fileAdapter
        }

        binding.btnSelectSafFolder.setOnClickListener {
            openSafTreeLauncher.launch(null)
        }

        binding.btnExtractZip.setOnClickListener {
            openZipLauncher.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
        }

        binding.btnInitWorkspace.setOnClickListener {
            viewModel.initializeDefaultWorkspace()
        }

        binding.btnInstallSampleGame.setOnClickListener {
            viewModel.installSampleGameInWorkspace()
        }

        binding.btnVerifyIntegrity.setOnClickListener {
            AppLogger.storage("Integrity", "Executando varredura SHA-256 nos arquivos locais e SAF...")
            viewModel.refreshStorageSnapshot()
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.storageSnapshot.collect { snapshot ->
                        if (snapshot == null) return@collect
                        binding.tvSafFolderStatus.text = if (snapshot.safFolderLabel != null) {
                            "Pasta SAF montada: ${snapshot.safFolderLabel}"
                        } else {
                            "Nenhuma pasta SAF selecionada"
                        }
                        binding.tvRuntimePath.text = "Diretório interno: ${snapshot.runtimeDirPath}"
                        fileAdapter.submitList(snapshot.verifiedFiles)
                        binding.tvFilesEmpty.visibility =
                            if (snapshot.verifiedFiles.isEmpty()) View.VISIBLE else View.GONE
                    }
                }
                launch {
                    viewModel.zipProgress.collect { prog ->
                        if (prog == null) {
                            binding.cardExtractionProgress.visibility = View.GONE
                            return@collect
                        }
                        binding.cardExtractionProgress.visibility = View.VISIBLE
                        binding.progressZip.progress = prog.percent
                        binding.tvZipPercent.text = "${prog.percent}%"
                        binding.tvZipStatus.text = when {
                            prog.errorMessage != null -> "Erro: ${prog.errorMessage}"
                            prog.isFinished -> "Concluído: ${prog.extractedFilesCount} arquivo(s) extraído(s)."
                            else -> "Extraindo: ${prog.currentFile}"
                        }
                    }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

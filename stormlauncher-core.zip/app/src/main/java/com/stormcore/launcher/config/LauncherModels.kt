package com.stormcore.launcher.config

enum class PerformanceProfile(
    val id: String,
    val displayName: String,
    val description: String,
    val shaderIntensity: Float
) {
    ECO("eco", "Economia", "Reduz carga de GPU e prioriza autonomia de bateria.", 0.72f),
    BALANCED("balanced", "Equilibrado", "Equilíbrio ideal entre fluidez térmica e fidelidade visual.", 1.0f),
    MAX("max", "Máximo", "Desbloqueia intensidade total de shaders e resposta imediata.", 1.25f);

    companion object {
        fun fromId(id: String?): PerformanceProfile =
            entries.firstOrNull { it.id == id } ?: BALANCED
    }
}

enum class ResolutionScale(val factor: Float, val label: String) {
    SCALE_0_5(0.50f, "0.5x"),
    SCALE_0_75(0.75f, "0.75x"),
    SCALE_1_0(1.00f, "1.0x"),
    SCALE_1_25(1.25f, "1.25x");

    companion object {
        fun fromFactor(factor: Float): ResolutionScale =
            entries.minByOrNull { kotlin.math.abs(it.factor - factor) } ?: SCALE_1_0
    }
}

enum class FpsLimit(val fps: Int, val label: String) {
    FPS_30(30, "30 FPS"),
    FPS_60(60, "60 FPS"),
    UNLIMITED(0, "Sem limite");

    companion object {
        fun fromFps(fps: Int): FpsLimit =
            entries.firstOrNull { it.fps == fps } ?: FPS_60
    }
}

enum class ShaderFilter(val modeInt: Int, val label: String, val description: String) {
    NONE(0, "Nenhum", "Pipeline nativo limpo sem filtros de pós-processamento."),
    SHARPEN(1, "Nitidez / Sharpen", "Convolução 3x3 de realce de bordas e micro-detalhes."),
    CEL_SHADING(2, "Cel-Shading / Contorno", "Quantização estilo anime com detecção de contorno Sobel."),
    VIBRANT(3, "Contraste Vibrante", "Mapeamento de contraste dinâmico e saturação energética.");

    companion object {
        fun fromMode(mode: Int): ShaderFilter =
            entries.firstOrNull { it.modeInt == mode } ?: NONE
    }
}

enum class EnvironmentStatus(val label: String) {
    PENDING("Arquivos Pendentes"),
    CONFIGURED("Configurado"),
    READY("Pronto")
}

data class HudElementPos(
    val id: String,
    val label: String,
    val xPercent: Float,
    val yPercent: Float
)

data class LauncherConfig(
    val performanceProfile: PerformanceProfile = PerformanceProfile.BALANCED,
    val resolutionScale: ResolutionScale = ResolutionScale.SCALE_1_0,
    val fpsLimit: FpsLimit = FpsLimit.FPS_60,
    val shaderFilter: ShaderFilter = ShaderFilter.NONE,
    val vsyncEnabled: Boolean = true,
    val showFpsCounter: Boolean = true,
    val virtualControlsEnabled: Boolean = true,
    val floatingAnalog: Boolean = false,
    val controlsOpacityPercent: Int = 75,
    val controlsScalePercent: Int = 100,
    val analogDeadzone: Float = 0.12f,
    val safTreeUri: String? = null,
    val hudPositions: Map<String, HudElementPos> = defaultHudPositions()
) {
    companion object {
        const val HUD_ANALOG = "ANALOG"
        const val HUD_A = "A"
        const val HUD_B = "B"
        const val HUD_X = "X"
        const val HUD_Y = "Y"
        const val HUD_L1 = "L1"
        const val HUD_R1 = "R1"
        const val HUD_START = "START"
        const val HUD_SELECT = "SELECT"

        fun defaultHudPositions(): Map<String, HudElementPos> = linkedMapOf(
            HUD_ANALOG to HudElementPos(HUD_ANALOG, "Analógico", 0.16f, 0.67f),
            HUD_L1 to HudElementPos(HUD_L1, "L1", 0.10f, 0.22f),
            HUD_R1 to HudElementPos(HUD_R1, "R1", 0.90f, 0.22f),
            HUD_SELECT to HudElementPos(HUD_SELECT, "SELECT", 0.41f, 0.88f),
            HUD_START to HudElementPos(HUD_START, "START", 0.59f, 0.88f),
            HUD_X to HudElementPos(HUD_X, "X", 0.78f, 0.62f),
            HUD_Y to HudElementPos(HUD_Y, "Y", 0.85f, 0.47f),
            HUD_A to HudElementPos(HUD_A, "A", 0.85f, 0.77f),
            HUD_B to HudElementPos(HUD_B, "B", 0.92f, 0.62f)
        )
    }
}

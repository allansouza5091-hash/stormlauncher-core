package com.stormcore.launcher.graphics

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.Choreographer
import android.view.View
import com.stormcore.launcher.controls.GamepadButton
import com.stormcore.launcher.controls.InputState
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.random.Random
import org.json.JSONObject

class StormArcadeView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs), Choreographer.FrameCallback {

    data class CartridgeParams(
        val title: String = "CyberCore Arena",
        val playerSpeed: Float = 420f,
        val fireRateMs: Long = 140L,
        val accentColor: Int = Color.rgb(0, 229, 255),
        val enemyColor: Int = Color.rgb(255, 140, 26),
        val startingWave: Int = 1
    )

    private data class Bullet(var x: Float, var y: Float, val vx: Float, val vy: Float, var life: Float)
    private data class Enemy(var x: Float, var y: Float, val radius: Float, val speed: Float, var hp: Int)
    private data class Particle(var x: Float, var y: Float, val vx: Float, val vy: Float, var life: Float, val color: Int)

    private var params = CartridgeParams()
    private var inputState = InputState()
    private var isPaused = false
    private var isRunning = false

    private var onFpsUpdated: ((Float) -> Unit)? = null

    private var playerX = 640f
    private var playerY = 360f
    private var playerHp = 100
    private var score = 0
    private var wave = 1
    private var initializedPos = false

    private var fireCooldownSec = 0f
    private var dashCooldownSec = 0f
    private var novaCooldownSec = 0f
    private var spawnTimerSec = 0f
    private var animTimeSec = 0f
    private var lastFrameNs = 0L

    private var fpsCount = 0
    private var fpsSampleStartNs = 0L

    private val bullets = ArrayList<Bullet>(64)
    private val enemies = ArrayList<Enemy>(48)
    private val particles = ArrayList<Particle>(128)

    private val bgPaint = Paint().apply { color = Color.rgb(8, 12, 22) }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(30, 0, 229, 255)
        strokeWidth = 2f
    }
    private val playerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(0, 229, 255)
        style = Paint.Style.FILL
    }
    private val playerRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }
    private val shieldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(180, 0, 229, 255)
        style = Paint.Style.STROKE
        strokeWidth = 6f
    }
    private val bulletPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(0, 229, 255)
    }
    private val enemyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 140, 26)
        style = Paint.Style.FILL
    }
    private val enemyStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 179, 0)
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }
    private val particlePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hudBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(175, 11, 15, 25)
    }
    private val hudTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 32f
        isFakeBoldText = true
    }

    fun configureCartridge(jsonRaw: String?, onFps: (Float) -> Unit) {
        onFpsUpdated = onFps
        if (!jsonRaw.isNullOrBlank()) {
            try {
                val obj = JSONObject(jsonRaw)
                params = CartridgeParams(
                    title = obj.optString("title", "CyberCore Arena"),
                    playerSpeed = obj.optDouble("playerSpeed", 420.0).toFloat().coerceIn(180f, 850f),
                    fireRateMs = obj.optLong("fireRateMs", 140L).coerceIn(60L, 500L),
                    accentColor = parseColorSafe(obj.optString("accentHex", "#00E5FF"), Color.rgb(0, 229, 255)),
                    enemyColor = parseColorSafe(obj.optString("enemyHex", "#FF8C1A"), Color.rgb(255, 140, 26)),
                    startingWave = obj.optInt("startingWave", 1).coerceAtLeast(1)
                )
            } catch (_: Exception) {
                params = CartridgeParams()
            }
        }
        wave = params.startingWave
        playerPaint.color = params.accentColor
        bulletPaint.color = params.accentColor
        enemyPaint.color = params.enemyColor
    }

    fun updateInput(state: InputState) {
        inputState = state
    }

    fun setPaused(paused: Boolean) {
        isPaused = paused
    }

    fun startLoop() {
        if (isRunning) return
        isRunning = true
        lastFrameNs = System.nanoTime()
        fpsSampleStartNs = lastFrameNs
        Choreographer.getInstance().postFrameCallback(this)
    }

    fun stopLoop() {
        isRunning = false
        Choreographer.getInstance().removeFrameCallback(this)
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!isRunning) return
        val dt = ((frameTimeNanos - lastFrameNs) / 1_000_000_000.0).toFloat().coerceIn(0f, 0.05f)
        lastFrameNs = frameTimeNanos

        if (!isPaused && width > 0 && height > 0) {
            stepSimulation(dt)
        }
        invalidate()

        fpsCount++
        val elapsed = frameTimeNanos - fpsSampleStartNs
        if (elapsed >= 350_000_000L) {
            val fps = (fpsCount * 1_000_000_000.0 / elapsed).toFloat()
            fpsCount = 0
            fpsSampleStartNs = frameTimeNanos
            onFpsUpdated?.invoke(fps)
        }

        Choreographer.getInstance().postFrameCallback(this)
    }

    private fun stepSimulation(dt: Float) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (!initializedPos) {
            playerX = w * 0.5f
            playerY = h * 0.55f
            initializedPos = true
        }

        animTimeSec += dt
        fireCooldownSec = (fireCooldownSec - dt).coerceAtLeast(0f)
        dashCooldownSec = (dashCooldownSec - dt).coerceAtLeast(0f)
        novaCooldownSec = (novaCooldownSec - dt).coerceAtLeast(0f)

        val btns = inputState.pressedButtons
        var ax = inputState.analogX
        var ay = inputState.analogY
        if (btns.contains(GamepadButton.DPAD_LEFT)) ax -= 1f
        if (btns.contains(GamepadButton.DPAD_RIGHT)) ax += 1f
        if (btns.contains(GamepadButton.DPAD_UP)) ay -= 1f
        if (btns.contains(GamepadButton.DPAD_DOWN)) ay += 1f
        val mag = hypot(ax.toDouble(), ay.toDouble()).toFloat()
        if (mag > 1f) {
            ax /= mag
            ay /= mag
        }

        val dashing = btns.contains(GamepadButton.B) && dashCooldownSec <= 0f && mag > 0.1f
        val speed = if (dashing) params.playerSpeed * 2.4f else params.playerSpeed
        if (dashing) {
            dashCooldownSec = 0.65f
            spawnBurst(playerX, playerY, params.accentColor, 14)
        }

        playerX = (playerX + ax * speed * dt).coerceIn(32f, w - 32f)
        playerY = (playerY + ay * speed * dt).coerceIn(88f, h - 32f)

        if ((btns.contains(GamepadButton.A) || btns.contains(GamepadButton.R1)) && fireCooldownSec <= 0f) {
            fireCooldownSec = params.fireRateMs / 1000f
            val angle = if (mag > 0.15f) atan2(ay.toDouble(), ax.toDouble()) else -Math.PI / 2.0
            val bSpeed = 760f
            bullets.add(
                Bullet(
                    x = playerX,
                    y = playerY,
                    vx = (cos(angle) * bSpeed).toFloat(),
                    vy = (sin(angle) * bSpeed).toFloat(),
                    life = 1.6f
                )
            )
        }

        if (btns.contains(GamepadButton.X) && novaCooldownSec <= 0f) {
            novaCooldownSec = 2.0f
            spawnBurst(playerX, playerY, Color.rgb(255, 179, 0), 28)
            val iter = enemies.iterator()
            while (iter.hasNext()) {
                val e = iter.next()
                if (hypot((e.x - playerX).toDouble(), (e.y - playerY).toDouble()) < 240.0) {
                    spawnBurst(e.x, e.y, params.enemyColor, 10)
                    iter.remove()
                    score += 25
                }
            }
        }

        val shieldActive = btns.contains(GamepadButton.Y) || btns.contains(GamepadButton.L1)

        spawnTimerSec += dt
        val spawnInterval = (1.05f - wave * 0.07f).coerceAtLeast(0.28f)
        if (spawnTimerSec >= spawnInterval) {
            spawnTimerSec = 0f
            spawnEnemy(w, h)
        }
        wave = params.startingWave + (score / 250)

        // Update bullets
        var bi = bullets.size - 1
        while (bi >= 0) {
            val b = bullets[bi]
            b.x += b.vx * dt
            b.y += b.vy * dt
            b.life -= dt
            if (b.life <= 0f || b.x < -30f || b.x > w + 30f || b.y < -30f || b.y > h + 30f) {
                bullets.removeAt(bi)
            }
            bi--
        }

        // Update enemies & collisions
        var ei = enemies.size - 1
        while (ei >= 0) {
            val e = enemies[ei]
            val ang = atan2((playerY - e.y).toDouble(), (playerX - e.x).toDouble())
            e.x += (cos(ang) * e.speed * dt).toFloat()
            e.y += (sin(ang) * e.speed * dt).toFloat()

            var destroyed = false
            var j = bullets.size - 1
            while (j >= 0) {
                val b = bullets[j]
                if (hypot((e.x - b.x).toDouble(), (e.y - b.y).toDouble()) <= e.radius + 10.0) {
                    bullets.removeAt(j)
                    e.hp--
                    if (e.hp <= 0) {
                        spawnBurst(e.x, e.y, params.enemyColor, 12)
                        enemies.removeAt(ei)
                        score += 15
                        destroyed = true
                        break
                    }
                }
                j--
            }
            if (destroyed) {
                ei--
                continue
            }

            if (hypot((e.x - playerX).toDouble(), (e.y - playerY).toDouble()) <= e.radius + 24.0) {
                spawnBurst(e.x, e.y, Color.RED, 14)
                enemies.removeAt(ei)
                if (!shieldActive) {
                    playerHp = (playerHp - 15).coerceAtLeast(0)
                    if (playerHp == 0) {
                        playerHp = 100
                        score = 0
                        wave = params.startingWave
                        enemies.clear()
                        break
                    }
                }
            }
            ei--
        }

        // Update particles
        var pi = particles.size - 1
        while (pi >= 0) {
            val pt = particles[pi]
            pt.x += pt.vx * dt
            pt.y += pt.vy * dt
            pt.life -= dt
            if (pt.life <= 0f) {
                particles.removeAt(pi)
            }
            pi--
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawRect(0f, 0f, w, h, bgPaint)

        val step = 64f
        val offset = (animTimeSec * 36f) % step
        var gx = offset
        while (gx < w) {
            canvas.drawLine(gx, 0f, gx, h, gridPaint)
            gx += step
        }
        var gy = offset
        while (gy < h) {
            canvas.drawLine(0f, gy, w, gy, gridPaint)
            gy += step
        }

        for (b in bullets) {
            canvas.drawCircle(b.x, b.y, 8f, bulletPaint)
        }
        for (e in enemies) {
            canvas.drawCircle(e.x, e.y, e.radius, enemyPaint)
            canvas.drawCircle(e.x, e.y, e.radius, enemyStrokePaint)
        }
        for (pt in particles) {
            particlePaint.color = pt.color
            particlePaint.alpha = (pt.life * 320f).toInt().coerceIn(0, 255)
            canvas.drawRect(pt.x - 4f, pt.y - 4f, pt.x + 4f, pt.y + 4f, particlePaint)
        }

        val shieldActive = inputState.pressedButtons.contains(GamepadButton.Y) ||
            inputState.pressedButtons.contains(GamepadButton.L1)
        if (shieldActive) {
            canvas.drawCircle(playerX, playerY, 38f, shieldPaint)
        }
        canvas.drawCircle(playerX, playerY, 24f, playerPaint)
        canvas.drawCircle(playerX, playerY, 24f, playerRingPaint)

        canvas.drawRoundRect(20f, 76f, 540f, 134f, 14f, 14f, hudBgPaint)
        canvas.drawText(
            "${params.title}  •  SCORE $score  •  HP $playerHp  •  WAVE $wave",
            36f,
            116f,
            hudTextPaint
        )
    }

    private fun spawnEnemy(w: Float, h: Float) {
        val side = Random.nextInt(4)
        val (x, y) = when (side) {
            0 -> Random.nextFloat() * w to -30f
            1 -> (w + 30f) to Random.nextFloat() * h
            2 -> Random.nextFloat() * w to (h + 30f)
            else -> -30f to Random.nextFloat() * h
        }
        enemies.add(
            Enemy(
                x = x,
                y = y,
                radius = 18f + Random.nextFloat() * 10f,
                speed = 95f + wave * 16f + Random.nextFloat() * 45f,
                hp = 1 + (wave / 3)
            )
        )
    }

    private fun spawnBurst(x: Float, y: Float, color: Int, count: Int) {
        for (i in 0 until count) {
            val angle = Random.nextFloat() * (Math.PI * 2.0).toFloat()
            val speed = 80f + Random.nextFloat() * 260f
            particles.add(
                Particle(
                    x = x,
                    y = y,
                    vx = cos(angle) * speed,
                    vy = sin(angle) * speed,
                    life = 0.45f + Random.nextFloat() * 0.3f,
                    color = color
                )
            )
        }
    }

    private fun parseColorSafe(hex: String, fallback: Int): Int = try {
        Color.parseColor(hex)
    } catch (_: Exception) {
        fallback
    }
}

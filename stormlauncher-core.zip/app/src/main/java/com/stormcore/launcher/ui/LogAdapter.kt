package com.stormcore.launcher.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.R
import com.example.databinding.ItemLogEntryBinding
import com.stormcore.launcher.diagnostics.LogEntry
import com.stormcore.launcher.diagnostics.LogLevel

class LogAdapter : ListAdapter<LogEntry, LogAdapter.LogViewHolder>(DiffCallback) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LogViewHolder {
        val binding = ItemLogEntryBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return LogViewHolder(binding)
    }

    override fun onBindViewHolder(holder: LogViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class LogViewHolder(
        private val binding: ItemLogEntryBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(entry: LogEntry) {
            val ctx = binding.root.context
            binding.tvLogTimestamp.text = entry.timestamp
            binding.tvLogLevel.text = "[${entry.level.label}]"
            binding.tvLogMessage.text = "${entry.tag}: ${entry.message}"

            val levelColorRes = when (entry.level) {
                LogLevel.INFO -> R.color.storm_log_info
                LogLevel.SHADER -> R.color.storm_log_shader
                LogLevel.STORAGE -> R.color.storm_log_storage
                LogLevel.INPUT -> R.color.storm_log_input
                LogLevel.WARN -> R.color.storm_log_warn
                LogLevel.ERROR -> R.color.storm_log_error
            }
            binding.tvLogLevel.setTextColor(ContextCompat.getColor(ctx, levelColorRes))
        }
    }

    private object DiffCallback : DiffUtil.ItemCallback<LogEntry>() {
        override fun areItemsTheSame(oldItem: LogEntry, newItem: LogEntry): Boolean =
            oldItem.id == newItem.id

        override fun areContentsTheSame(oldItem: LogEntry, newItem: LogEntry): Boolean =
            oldItem == newItem
    }
}

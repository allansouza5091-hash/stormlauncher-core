package com.stormcore.launcher.controls

import android.content.Context
import android.hardware.input.InputManager
import android.os.Handler
import android.os.Looper
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import com.stormcore.launcher.diagnostics.AppLogger
import kotlin.math.abs

data class GamepadDeviceInfo(
    val deviceId: Int,
    val name: String,
    val vendorId: Int,
    val productId: Int,
    val descriptor: String
)

class GamepadHandler(
    context: Context,
    private val inputHub: UnifiedInputHub,
    private val onDevicesChanged: (List<GamepadDeviceInfo>) -> Unit = {}
) : InputManager.InputDeviceListener {

    private val inputManager =
        context.applicationContext.getSystemService(Context.INPUT_SERVICE) as InputManager

    var customDeadzone: Float = 0.12f

    fun register() {
        inputManager.registerInputDeviceListener(this, Handler(Looper.getMainLooper()))
        onDevicesChanged(detectConnectedGamepads())
    }

    fun unregister() {
        inputManager.unregisterInputDeviceListener(this)
    }

    fun detectConnectedGamepads(): List<GamepadDeviceInfo> {
        val result = mutableListOf<GamepadDeviceInfo>()
        for (deviceId in InputDevice.getDeviceIds()) {
            val device = InputDevice.getDevice(deviceId) ?: continue
            if (isGamepadDevice(device)) {
                result.add(
                    GamepadDeviceInfo(
                        deviceId = device.id,
                        name = device.name ?: "Gamepad #$deviceId",
                        vendorId = device.vendorId,
                        productId = device.productId,
                        descriptor = device.descriptor.take(12)
                    )
                )
            }
        }
        return result
    }

    override fun onInputDeviceAdded(deviceId: Int) {
        val device = InputDevice.getDevice(deviceId)
        if (device != null && isGamepadDevice(device)) {
            AppLogger.input("Gamepad", "Controle físico conectado: ${device.name}")
        }
        onDevicesChanged(detectConnectedGamepads())
    }

    override fun onInputDeviceRemoved(deviceId: Int) {
        AppLogger.input("Gamepad", "Controle físico desconectado (ID=$deviceId)")
        onDevicesChanged(detectConnectedGamepads())
    }

    override fun onInputDeviceChanged(deviceId: Int) {
        onDevicesChanged(detectConnectedGamepads())
    }

    fun handleGenericMotionEvent(event: MotionEvent): Boolean {
        if ((event.source and InputDevice.SOURCE_JOYSTICK) != InputDevice.SOURCE_JOYSTICK &&
            (event.source and InputDevice.SOURCE_GAMEPAD) != InputDevice.SOURCE_GAMEPAD
        ) {
            return false
        }
        if (event.action != MotionEvent.ACTION_MOVE) return false

        val device = event.device
        val deviceName = device?.name ?: "Gamepad"

        val lx = getCenteredAxis(event, device, MotionEvent.AXIS_X)
        val ly = getCenteredAxis(event, device, MotionEvent.AXIS_Y)
        val rx = getCenteredAxis(event, device, MotionEvent.AXIS_Z)
        val ry = getCenteredAxis(event, device, MotionEvent.AXIS_RZ)
        val hatX = event.getAxisValue(MotionEvent.AXIS_HAT_X)
        val hatY = event.getAxisValue(MotionEvent.AXIS_HAT_Y)

        val hatButtons = buildSet {
            if (hatX <= -0.5f) add(GamepadButton.DPAD_LEFT)
            if (hatX >= 0.5f) add(GamepadButton.DPAD_RIGHT)
            if (hatY <= -0.5f) add(GamepadButton.DPAD_UP)
            if (hatY >= 0.5f) add(GamepadButton.DPAD_DOWN)
        }

        inputHub.updatePhysicalAxes(lx, ly, rx, ry, hatButtons, deviceName)
        return true
    }

    fun handleKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (!isFromController(event)) return false
        val button = mapKeyCodeToButton(keyCode) ?: return false
        if (event.repeatCount == 0) {
            val deviceName = event.device?.name ?: "Gamepad"
            inputHub.updatePhysicalButton(button, true, deviceName)
        }
        return true
    }

    fun handleKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (!isFromController(event)) return false
        val button = mapKeyCodeToButton(keyCode) ?: return false
        val deviceName = event.device?.name ?: "Gamepad"
        inputHub.updatePhysicalButton(button, false, deviceName)
        return true
    }

    private fun getCenteredAxis(event: MotionEvent, device: InputDevice?, axis: Int): Float {
        val value = event.getAxisValue(axis)
        val rangeFlat = device?.getMotionRange(axis, event.source)?.flat ?: 0f
        val threshold = maxOf(rangeFlat, customDeadzone)
        return if (abs(value) > threshold) value.coerceIn(-1f, 1f) else 0f
    }

    private fun mapKeyCodeToButton(keyCode: Int): GamepadButton? = when (keyCode) {
        KeyEvent.KEYCODE_BUTTON_A -> GamepadButton.A
        KeyEvent.KEYCODE_BUTTON_B -> GamepadButton.B
        KeyEvent.KEYCODE_BUTTON_X -> GamepadButton.X
        KeyEvent.KEYCODE_BUTTON_Y -> GamepadButton.Y
        KeyEvent.KEYCODE_BUTTON_L1 -> GamepadButton.L1
        KeyEvent.KEYCODE_BUTTON_R1 -> GamepadButton.R1
        KeyEvent.KEYCODE_BUTTON_START -> GamepadButton.START
        KeyEvent.KEYCODE_BUTTON_SELECT -> GamepadButton.SELECT
        KeyEvent.KEYCODE_DPAD_UP -> GamepadButton.DPAD_UP
        KeyEvent.KEYCODE_DPAD_DOWN -> GamepadButton.DPAD_DOWN
        KeyEvent.KEYCODE_DPAD_LEFT -> GamepadButton.DPAD_LEFT
        KeyEvent.KEYCODE_DPAD_RIGHT -> GamepadButton.DPAD_RIGHT
        else -> null
    }

    private fun isFromController(event: KeyEvent): Boolean {
        val src = event.source
        return (src and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (src and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK ||
            (src and InputDevice.SOURCE_DPAD) == InputDevice.SOURCE_DPAD
    }

    private fun isGamepadDevice(device: InputDevice): Boolean {
        if (device.isVirtual) return false
        val sources = device.sources
        return (sources and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (sources and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
    }
}

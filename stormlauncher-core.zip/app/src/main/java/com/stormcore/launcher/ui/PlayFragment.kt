package com.stormcore.launcher.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.R
import com.example.databinding.FragmentPlayBinding
import com.stormcore.launcher.config.PerformanceProfile
import com.stormcore.launcher.diagnostics.AppLogger
import com.stormcore.launcher.storage.GameType
import com.stormcore.launcher.storage.PreflightCheck
import kotlinx.coroutines.launch

class PlayFragment : Fragment() {

    private var _binding: FragmentPlayBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()
    private var suppressToggleCallback = false

    private val gameAdapter = GameAdapter { game ->
        viewModel.selectGame(game)
    }

    private val quickSafPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            viewModel.onSafFolderSelected(uri)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPlayBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rvDetectedGames.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = gameAdapter
        }

        binding.btnQuickPickSaf.setOnClickListener {
            quickSafPicker.launch(null)
        }

        binding.btnQuickInstallDemo.setOnClickListener {
            viewModel.installSampleGameInWorkspace()
            Toast.makeText(
                requireContext(),
                "Pacote jogável instalado! Selecione e clique em INICIAR AMBIENTE.",
                Toast.LENGTH_SHORT
            ).show()
        }

        binding.btnLaunchEnvironment.setOnClickListener {
            val selected = viewModel.selectedGame.value
            if (selected != null && !selected.type.isPlayable) {
                val msg = if (selected.type == GameType.PC_NATIVE_UNSUPPORTED) {
                    "Este arquivo é um executável Windows (.exe) nativo. Para rodar jogos de PC neste launcher, use builds PC Web/NW.js/RPG Maker (www/index.html) ou HTML5/WebGL."
                } else {
                    "Formato binário externo não suportado diretamente. Adicione um jogo HTML5/WebGL (index.html), PC Web, Storm2D ou Shader (.glsl)."
                }
                Toast.makeText(requireContext(), msg, Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            val intent = Intent(requireContext(), GameRuntimeActivity::class.java)
            if (selected != null) {
                intent.putExtra(GameRuntimeActivity.EXTRA_GAME_TITLE, selected.title)
                intent.putExtra(GameRuntimeActivity.EXTRA_GAME_TYPE, selected.type.name)
                intent.putExtra(GameRuntimeActivity.EXTRA_GAME_ROOT, selected.rootPathOrUri)
                intent.putExtra(GameRuntimeActivity.EXTRA_GAME_ENTRY, selected.entryPathOrUri)
                intent.putExtra(GameRuntimeActivity.EXTRA_GAME_IS_SAF, selected.isSafSource)
                AppLogger.i("Launcher", "Iniciando jogo '${selected.title}' (${selected.type.badge})...")
            } else {
                AppLogger.i("Launcher", "Nenhum jogo selecionado; iniciando arena OpenGL ES 3.0 padrão.")
            }
            startActivity(intent)
        }

        binding.togglePerfProfile.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked || suppressToggleCallback) return@addOnButtonCheckedListener
            val profile = when (checkedId) {
                R.id.btnProfileEco -> PerformanceProfile.ECO
                R.id.btnProfileMax -> PerformanceProfile.MAX
                else -> PerformanceProfile.BALANCED
            }
            viewModel.setPerformanceProfile(profile)
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.config.collect { cfg ->
                        suppressToggleCallback = true
                        val btnId = when (cfg.performanceProfile) {
                            PerformanceProfile.ECO -> R.id.btnProfileEco
                            PerformanceProfile.BALANCED -> R.id.btnProfileBalanced
                            PerformanceProfile.MAX -> R.id.btnProfileMax
                        }
                        if (binding.togglePerfProfile.checkedButtonId != btnId) {
                            binding.togglePerfProfile.check(btnId)
                        }
                        suppressToggleCallback = false

                        binding.tvProfileDescription.text = cfg.performanceProfile.description
                        binding.tvActiveSummary.text =
                            "GLES 3.0  •  ${cfg.resolutionScale.label}  •  ${cfg.fpsLimit.label}  •  Shader: ${cfg.shaderFilter.label}"
                    }
                }
                launch {
                    viewModel.storageSnapshot.collect { snapshot ->
                        val games = snapshot?.detectedGames.orEmpty()
                        gameAdapter.submitList(games)
                        binding.tvGamesEmpty.visibility =
                            if (games.isEmpty()) View.VISIBLE else View.GONE
                        renderPreflightChecks(snapshot?.preflightChecks.orEmpty())
                    }
                }
                launch {
                    viewModel.zipProgress.collect { prog ->
                        if (prog == null || (prog.isFinished && prog.errorMessage == null)) {
                            binding.playZipProgressGroup.visibility = View.GONE
                        } else {
                            binding.playZipProgressGroup.visibility = View.VISIBLE
                            binding.progressPlayZip.progress = prog.percent
                            binding.tvPlayZipStatus.text = if (prog.errorMessage != null) {
                                "Erro ao extrair ZIP: ${prog.errorMessage}"
                            } else {
                                "Extraindo .ZIP (${prog.percent}%): ${prog.currentFile}"
                            }
                        }
                    }
                }
                launch {
                    viewModel.selectedGame.collect { selected ->
                        gameAdapter.selectedGameId = selected?.id
                        if (selected != null) {
                            binding.tvSelectedGameHero.text = selected.title.uppercase()
                            binding.tvSelectedGameDesc.text =
                                "${selected.type.badge} • ${selected.sourceLabel} — ${selected.description}"
                        } else {
                            binding.tvSelectedGameHero.setText(R.string.play_hero_title)
                            binding.tvSelectedGameDesc.setText(R.string.play_hero_desc)
                        }
                    }
                }
            }
        }
    }

    private fun renderPreflightChecks(checks: List<PreflightCheck>) {
        val container = binding.preflightContainer
        container.removeAllViews()
        val ctx = requireContext()

        if (checks.isEmpty()) {
            val tv = TextView(ctx).apply {
                text = "Analisando arquivos locais..."
                textSize = 12f
                setTextColor(ContextCompat.getColor(ctx, R.color.storm_text_secondary))
            }
            container.addView(tv)
            return
        }

        checks.forEach { check ->
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, 4, 0, 8)
            }
            val title = TextView(ctx).apply {
                val prefix = if (check.passed) "[OK]" else "[PENDENTE]"
                text = "$prefix ${check.title}"
                textSize = 12f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(
                    ContextCompat.getColor(
                        ctx,
                        if (check.passed) R.color.storm_status_ready else R.color.storm_status_pending
                    )
                )
            }
            val detail = TextView(ctx).apply {
                text = check.detail
                textSize = 11f
                setTextColor(ContextCompat.getColor(ctx, R.color.storm_text_secondary))
            }
            row.addView(title)
            row.addView(detail)
            container.addView(row)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

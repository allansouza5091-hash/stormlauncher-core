package com.stormcore.launcher.storage

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.stormcore.launcher.diagnostics.AppLogger
import java.io.File
import java.io.InputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

data class SafZipCandidate(
    val name: String,
    val uri: Uri,
    val sizeBytes: Long
)

class GameScanner(private val context: Context) {

    private val appContext = context.applicationContext

    suspend fun findPendingZipsInSafFolder(
        safUriString: String?,
        runtimeRootDir: File
    ): List<SafZipCandidate> = withContext(Dispatchers.IO) {
        if (safUriString.isNullOrBlank()) return@withContext emptyList()
        val rootDoc = DocumentFile.fromTreeUri(appContext, Uri.parse(safUriString))
            ?: return@withContext emptyList()
        if (!rootDoc.exists() || !rootDoc.canRead()) return@withContext emptyList()

        val result = mutableListOf<SafZipCandidate>()
        for (child in rootDoc.listFiles()) {
            if (child.isFile) {
                val name = child.name.orEmpty()
                if (name.lowercase().endsWith(".zip")) {
                    val safeDirName = sanitizeZipFolderName(name)
                    val marker = File(File(runtimeRootDir, safeDirName), ".storm_extracted")
                    if (!marker.exists()) {
                        result.add(SafZipCandidate(name, child.uri, child.length()))
                    }
                }
            }
        }
        result
    }

    fun sanitizeZipFolderName(zipName: String): String {
        return zipName.substringBeforeLast('.')
            .replace(Regex("[^a-zA-Z0-9._-]"), "_")
            .ifBlank { "extracted_pkg" }
    }

    suspend fun scanAllGames(safUriString: String?, runtimeRootDir: File): List<GameEntry> =
        withContext(Dispatchers.IO) {
            val games = mutableListOf<GameEntry>()

            if (!safUriString.isNullOrBlank()) {
                val rootUri = Uri.parse(safUriString)
                val rootDoc = DocumentFile.fromTreeUri(appContext, rootUri)
                if (rootDoc != null && rootDoc.exists() && rootDoc.canRead()) {
                    scanSafDirectory(rootDoc, depth = 0, out = games)
                }
            }

            if (runtimeRootDir.exists() && runtimeRootDir.isDirectory) {
                scanLocalDirectory(runtimeRootDir, depth = 0, out = games)
            }

            games.distinctBy { it.id }
        }

    private fun scanSafDirectory(
        dir: DocumentFile,
        depth: Int,
        out: MutableList<GameEntry>
    ) {
        if (depth > 3) return
        val children = dir.listFiles()
        val files = children.filter { it.isFile }
        val dirs = children.filter { it.isDirectory }

        val dirName = dir.name ?: "Pasta SAF"
        val dirUriStr = dir.uri.toString()

        // 1. Direct HTML5 / WebGL game
        val htmlEntry = files.firstOrNull { it.name.equals("index.html", ignoreCase = true) }
            ?: files.firstOrNull {
                val n = it.name.orEmpty().lowercase()
                n.endsWith(".html") || n.endsWith(".htm")
            }
        if (htmlEntry != null) {
            out.add(
                GameEntry(
                    id = "saf_web_${dirUriStr.hashCode()}",
                    title = dirName,
                    type = GameType.HTML5_WEB,
                    sourceLabel = "Pasta SAF",
                    rootPathOrUri = dirUriStr,
                    entryPathOrUri = htmlEntry.uri.toString(),
                    isSafSource = true,
                    fileCount = children.size,
                    description = "Jogo Web/HTML5 pronto para execução offline (${htmlEntry.name})."
                )
            )
        }

        // 2. PC NW.js / RPG Maker MV-MZ / Electron unpacked folder (www/index.html or resources/app/index.html)
        val wwwDir = dirs.firstOrNull { it.name.equals("www", ignoreCase = true) }
        val wwwHtml = wwwDir?.listFiles()?.firstOrNull { it.name.equals("index.html", ignoreCase = true) }
        val resourcesAppHtml = dirs.firstOrNull { it.name.equals("resources", ignoreCase = true) }
            ?.listFiles()?.firstOrNull { it.isDirectory && it.name.equals("app", ignoreCase = true) }
        val appHtml = resourcesAppHtml?.listFiles()?.firstOrNull { it.name.equals("index.html", ignoreCase = true) }

        if (wwwDir != null && wwwHtml != null) {
            out.add(
                GameEntry(
                    id = "saf_nwjs_${wwwDir.uri.toString().hashCode()}",
                    title = "$dirName (PC Web)",
                    type = GameType.PC_NWJS_WEB,
                    sourceLabel = "Pasta PC (SAF)",
                    rootPathOrUri = wwwDir.uri.toString(),
                    entryPathOrUri = wwwHtml.uri.toString(),
                    isSafSource = true,
                    fileCount = wwwDir.listFiles().size,
                    description = "Build PC NW.js / RPG Maker detectado (www/index.html) — jogável diretamente."
                )
            )
        } else if (resourcesAppHtml != null && appHtml != null) {
            out.add(
                GameEntry(
                    id = "saf_elec_${resourcesAppHtml.uri.toString().hashCode()}",
                    title = "$dirName (PC Electron)",
                    type = GameType.PC_NWJS_WEB,
                    sourceLabel = "Pasta PC (SAF)",
                    rootPathOrUri = resourcesAppHtml.uri.toString(),
                    entryPathOrUri = appHtml.uri.toString(),
                    isSafSource = true,
                    fileCount = resourcesAppHtml.listFiles().size,
                    description = "Build PC Electron detectado (resources/app/index.html) — jogável diretamente."
                )
            )
        }

        // 3. Storm2D Cartridge
        val cartridgeFile = files.firstOrNull { it.name.equals("cartridge.json", ignoreCase = true) }
        if (cartridgeFile != null) {
            val title = readJsonTitleFromUri(cartridgeFile.uri) ?: dirName
            out.add(
                GameEntry(
                    id = "saf_2d_${cartridgeFile.uri.toString().hashCode()}",
                    title = title,
                    type = GameType.STORM_2D,
                    sourceLabel = "Pasta SAF",
                    rootPathOrUri = dirUriStr,
                    entryPathOrUri = cartridgeFile.uri.toString(),
                    isSafSource = true,
                    fileCount = children.size,
                    description = "Cartucho nativo Storm2D 60 FPS com analógico e botões."
                )
            )
        }

        // 4. GLSL ES 3.0 Shader Game
        val shaderFiles = files.filter {
            val n = it.name.orEmpty().lowercase()
            n.endsWith(".frag") || n.endsWith(".glsl")
        }
        shaderFiles.forEach { sf ->
            val name = sf.name ?: "Shader"
            out.add(
                GameEntry(
                    id = "saf_glsl_${sf.uri.toString().hashCode()}",
                    title = name.substringBeforeLast('.'),
                    type = GameType.GLSL_SHADER,
                    sourceLabel = "Pasta SAF",
                    rootPathOrUri = dirUriStr,
                    entryPathOrUri = sf.uri.toString(),
                    isSafSource = true,
                    fileCount = 1,
                    description = "Cartucho de shader OpenGL ES 3.0 ($name)."
                )
            )
        }

        // 5. Native Windows PC .exe inspection (only if no playable web entry exists in this folder)
        if (htmlEntry == null && wwwHtml == null && appHtml == null && cartridgeFile == null && shaderFiles.isEmpty()) {
            val exeFile = files.firstOrNull { it.name.orEmpty().lowercase().endsWith(".exe") }
            if (exeFile != null) {
                val pe = PeExecutableInspector.inspectUri(appContext, exeFile.uri)
                val engineHint = detectPcEngineFromNames(files.mapNotNull { it.name }, dirs.mapNotNull { it.name })
                val exeName = exeFile.name ?: "Game.exe"
                AppLogger.storage(
                    "PE-Scan",
                    "Executável PC detectado: $exeName | ${pe.archLabel} | ${pe.subsystemLabel} | Engine=$engineHint"
                )
                out.add(
                    GameEntry(
                        id = "saf_exe_${exeFile.uri.toString().hashCode()}",
                        title = "$dirName ($exeName)",
                        type = GameType.PC_NATIVE_UNSUPPORTED,
                        sourceLabel = "PC Windows",
                        rootPathOrUri = dirUriStr,
                        entryPathOrUri = exeFile.uri.toString(),
                        isSafSource = true,
                        fileCount = children.size,
                        description = "Binário ${pe.archLabel} (${pe.subsystemLabel} • $engineHint). Executáveis nativos Win32/x64 exigem Wine/Box64 + DXVK e não podem ser executados diretamente neste APK."
                    )
                )
            }
        }

        dirs.forEach { subDir ->
            if (!subDir.name.equals("www", ignoreCase = true) &&
                !subDir.name.equals("resources", ignoreCase = true)
            ) {
                scanSafDirectory(subDir, depth + 1, out)
            }
        }
    }

    private fun scanLocalDirectory(
        dir: File,
        depth: Int,
        out: MutableList<GameEntry>
    ) {
        if (depth > 3) return
        val children = dir.listFiles()?.toList().orEmpty()
        val files = children.filter { it.isFile }
        val dirs = children.filter { it.isDirectory }

        val dirTitle = dir.name.takeIf { it != StorageManager.RUNTIME_DIR_NAME } ?: "Pacote Extraído"

        val htmlEntry = files.firstOrNull { it.name.equals("index.html", ignoreCase = true) }
            ?: files.firstOrNull {
                val n = it.name.lowercase()
                n.endsWith(".html") || n.endsWith(".htm")
            }
        if (htmlEntry != null) {
            out.add(
                GameEntry(
                    id = "local_web_${dir.absolutePath.hashCode()}",
                    title = dirTitle,
                    type = GameType.HTML5_WEB,
                    sourceLabel = "Interno (ZIP/Demo)",
                    rootPathOrUri = dir.absolutePath,
                    entryPathOrUri = htmlEntry.absolutePath,
                    isSafSource = false,
                    fileCount = children.size,
                    description = "Jogo HTML5/WebGL extraído localmente (${htmlEntry.name})."
                )
            )
        }

        val wwwDir = File(dir, "www")
        val wwwHtml = File(wwwDir, "index.html")
        val appDir = File(dir, "resources/app")
        val appHtml = File(appDir, "index.html")

        if (wwwHtml.exists()) {
            out.add(
                GameEntry(
                    id = "local_nwjs_${wwwDir.absolutePath.hashCode()}",
                    title = "$dirTitle (PC Web)",
                    type = GameType.PC_NWJS_WEB,
                    sourceLabel = "ZIP Extraído (PC)",
                    rootPathOrUri = wwwDir.absolutePath,
                    entryPathOrUri = wwwHtml.absolutePath,
                    isSafSource = false,
                    fileCount = wwwDir.listFiles()?.size ?: 1,
                    description = "Build PC NW.js / RPG Maker extraído (www/index.html) — jogável diretamente."
                )
            )
        } else if (appHtml.exists()) {
            out.add(
                GameEntry(
                    id = "local_elec_${appDir.absolutePath.hashCode()}",
                    title = "$dirTitle (PC Electron)",
                    type = GameType.PC_NWJS_WEB,
                    sourceLabel = "ZIP Extraído (PC)",
                    rootPathOrUri = appDir.absolutePath,
                    entryPathOrUri = appHtml.absolutePath,
                    isSafSource = false,
                    fileCount = appDir.listFiles()?.size ?: 1,
                    description = "Build PC Electron extraído (resources/app/index.html) — jogável diretamente."
                )
            )
        }

        val cartridgeFile = files.firstOrNull { it.name.equals("cartridge.json", ignoreCase = true) }
        if (cartridgeFile != null) {
            val title = readJsonTitleFromFile(cartridgeFile) ?: dirTitle
            out.add(
                GameEntry(
                    id = "local_2d_${cartridgeFile.absolutePath.hashCode()}",
                    title = title,
                    type = GameType.STORM_2D,
                    sourceLabel = "Interno (ZIP/Demo)",
                    rootPathOrUri = dir.absolutePath,
                    entryPathOrUri = cartridgeFile.absolutePath,
                    isSafSource = false,
                    fileCount = children.size,
                    description = "Cartucho nativo Storm2D pronto para jogar."
                )
            )
        }

        val shaderFiles = files.filter {
            val n = it.name.lowercase()
            n.endsWith(".frag") || n.endsWith(".glsl")
        }
        shaderFiles.forEach { sf ->
            out.add(
                GameEntry(
                    id = "local_glsl_${sf.absolutePath.hashCode()}",
                    title = sf.nameWithoutExtension,
                    type = GameType.GLSL_SHADER,
                    sourceLabel = "Interno (ZIP/Demo)",
                    rootPathOrUri = dir.absolutePath,
                    entryPathOrUri = sf.absolutePath,
                    isSafSource = false,
                    fileCount = 1,
                    description = "Shader GLSL ES 3.0 local (${sf.name})."
                )
            )
        }

        if (htmlEntry == null && !wwwHtml.exists() && !appHtml.exists() && cartridgeFile == null && shaderFiles.isEmpty()) {
            val exeFile = files.firstOrNull { it.name.lowercase().endsWith(".exe") }
            if (exeFile != null) {
                val pe = PeExecutableInspector.inspectFile(exeFile)
                val engineHint = detectPcEngineFromNames(files.map { it.name }, dirs.map { it.name })
                out.add(
                    GameEntry(
                        id = "local_exe_${exeFile.absolutePath.hashCode()}",
                        title = "$dirTitle (${exeFile.name})",
                        type = GameType.PC_NATIVE_UNSUPPORTED,
                        sourceLabel = "ZIP PC Windows",
                        rootPathOrUri = dir.absolutePath,
                        entryPathOrUri = exeFile.absolutePath,
                        isSafSource = false,
                        fileCount = children.size,
                        description = "Binário ${pe.archLabel} (${pe.subsystemLabel} • $engineHint). Executáveis nativos Win32/x64 exigem Wine/Box64 + DXVK e não podem ser executados diretamente neste APK."
                    )
                )
            }
        }

        dirs.forEach { subDir ->
            if (!subDir.name.equals("www", ignoreCase = true) &&
                !subDir.name.equals("resources", ignoreCase = true)
            ) {
                scanLocalDirectory(subDir, depth + 1, out)
            }
        }
    }

    private fun detectPcEngineFromNames(fileNames: List<String>, dirNames: List<String>): String {
        val lowerFiles = fileNames.map { it.lowercase() }
        val lowerDirs = dirNames.map { it.lowercase() }
        return when {
            lowerFiles.any { it == "unityplayer.dll" || it == "gameassembly.dll" } -> "Unity Engine"
            lowerFiles.any { it.contains("nw.dll") || it == "nw_elf.dll" } -> "NW.js / RPG Maker"
            lowerDirs.any { it == "engine" } && lowerFiles.any { it.endsWith(".exe") } -> "Unreal / PC Engine"
            lowerFiles.any { it.endsWith(".pck") } -> "Godot Engine"
            lowerFiles.any { it.contains("steam_api") } -> "Steamworks PC Build"
            else -> "Win32 / DirectX"
        }
    }

    suspend fun buildAssetIndex(game: GameEntry): Map<String, Uri> = withContext(Dispatchers.IO) {
        val map = HashMap<String, Uri>()
        if (game.isSafSource) {
            val dir = DocumentFile.fromTreeUri(appContext, Uri.parse(game.rootPathOrUri))
                ?: return@withContext map
            indexSafRecursive(dir, "", map)
            if (map.isEmpty()) {
                DocumentFile.fromSingleUri(appContext, Uri.parse(game.entryPathOrUri))?.let { single ->
                    val name = single.name ?: "index.html"
                    map[name.lowercase()] = single.uri
                }
            }
        } else {
            val rootDir = File(game.rootPathOrUri)
            if (rootDir.exists() && rootDir.isDirectory) {
                rootDir.walkTopDown().filter { it.isFile }.forEach { f ->
                    val rel = f.relativeTo(rootDir).path.replace('\\', '/').lowercase()
                    map[rel] = Uri.fromFile(f)
                }
            }
        }
        AppLogger.storage("AssetIndex", "Indexados ${map.size} arquivo(s) para '${game.title}'.")
        map
    }

    private fun indexSafRecursive(
        dir: DocumentFile,
        prefix: String,
        out: MutableMap<String, Uri>
    ) {
        for (child in dir.listFiles()) {
            val name = child.name ?: continue
            val relPath = if (prefix.isEmpty()) name else "$prefix/$name"
            if (child.isDirectory) {
                indexSafRecursive(child, relPath, out)
            } else if (child.isFile) {
                out[relPath.lowercase()] = child.uri
            }
        }
    }

    suspend fun readTextContent(entryPathOrUri: String, isSaf: Boolean): String? =
        withContext(Dispatchers.IO) {
            try {
                if (isSaf) {
                    appContext.contentResolver.openInputStream(Uri.parse(entryPathOrUri))
                        ?.bufferedReader()
                        ?.use { it.readText() }
                } else {
                    File(entryPathOrUri).takeIf { it.exists() }?.readText()
                }
            } catch (e: Exception) {
                AppLogger.e("Scanner", "Erro ao ler arquivo do jogo: ${e.message}")
                null
            }
        }

    fun openAssetStream(uri: Uri): InputStream? {
        return try {
            if (uri.scheme == "file") {
                File(uri.path ?: return null).inputStream()
            } else {
                appContext.contentResolver.openInputStream(uri)
            }
        } catch (_: Exception) {
            null
        }
    }

    suspend fun installPlayableSampleGame(
        safUriString: String?,
        runtimeRootDir: File
    ): Boolean = withContext(Dispatchers.IO) {
        val htmlContent = SAMPLE_WEB_GAME_HTML
        val cartridgeContent = SAMPLE_STORM2D_JSON

        if (!safUriString.isNullOrBlank()) {
            try {
                val rootDoc = DocumentFile.fromTreeUri(appContext, Uri.parse(safUriString))
                if (rootDoc != null && rootDoc.canWrite()) {
                    val gameDir = rootDoc.findFile("StormStrike_Web")
                        ?: rootDoc.createDirectory("StormStrike_Web")
                    if (gameDir != null) {
                        gameDir.findFile("index.html")?.delete()
                        val htmlDoc = gameDir.createFile("text/html", "index.html")
                        if (htmlDoc != null) {
                            appContext.contentResolver.openOutputStream(htmlDoc.uri)?.use { os ->
                                os.write(htmlContent.toByteArray(Charsets.UTF_8))
                            }
                            AppLogger.storage(
                                "SampleGame",
                                "Jogo HTML5 'StormStrike_Web/index.html' gravado na pasta SAF!"
                            )
                            return@withContext true
                        }
                    }
                }
            } catch (e: Exception) {
                AppLogger.w("SampleGame", "Pasta SAF somente-leitura; instalando no workspace interno: ${e.message}")
            }
        }

        return@withContext try {
            val webDir = File(runtimeRootDir, "StormStrike_Web").apply { mkdirs() }
            File(webDir, "index.html").writeText(htmlContent, Charsets.UTF_8)

            val nativeDir = File(runtimeRootDir, "CyberCore_Arena").apply { mkdirs() }
            File(nativeDir, "cartridge.json").writeText(cartridgeContent, Charsets.UTF_8)

            AppLogger.storage(
                "SampleGame",
                "Jogos jogáveis instalados em ${runtimeRootDir.absolutePath} (StormStrike_Web + CyberCore_Arena)."
            )
            true
        } catch (e: Exception) {
            AppLogger.e("SampleGame", "Falha ao gravar pacote de demonstração: ${e.message}")
            false
        }
    }

    private fun readJsonTitleFromUri(uri: Uri): String? {
        return try {
            val raw = appContext.contentResolver.openInputStream(uri)
                ?.bufferedReader()?.use { it.readText() } ?: return null
            JSONObject(raw).optString("title").takeIf { it.isNotBlank() }
        } catch (_: Exception) {
            null
        }
    }

    private fun readJsonTitleFromFile(file: File): String? {
        return try {
            JSONObject(file.readText()).optString("title").takeIf { it.isNotBlank() }
        } catch (_: Exception) {
            null
        }
    }

    companion object {
        private val SAMPLE_STORM2D_JSON = """
            {
              "title": "CyberCore Arena (Storm2D)",
              "playerSpeed": 430.0,
              "fireRateMs": 140,
              "accentHex": "#00E5FF",
              "enemyHex": "#FF8C1A",
              "startingWave": 1
            }
        """.trimIndent()

        private val SAMPLE_WEB_GAME_HTML = """
            <!DOCTYPE html>
            <html lang="pt-BR">
            <head>
              <meta charset="UTF-8" />
              <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
              <title>StormStrike Web Arcade</title>
              <style>
                * { box-sizing: border-box; margin: 0; padding: 0; user-select: none; }
                body { background: #070B14; overflow: hidden; font-family: monospace; color: #F1F5F9; }
                canvas { display: block; width: 100vw; height: 100vh; }
                #hud {
                  position: fixed; top: 58px; left: 16px;
                  background: rgba(11, 15, 25, 0.72); border: 1px solid #2A3650;
                  border-radius: 10px; padding: 8px 14px; font-size: 13px; pointer-events: none;
                }
                .cyan { color: #00E5FF; font-weight: bold; }
                .orange { color: #FF8C1A; font-weight: bold; }
              </style>
            </head>
            <body>
              <canvas id="game"></canvas>
              <div id="hud">
                <span class="cyan">STORMSTRIKE WEB</span> |
                SCORE: <span id="score" class="orange">0</span> |
                HP: <span id="hp" class="cyan">100</span> |
                WAVE: <span id="wave">1</span>
                <div style="font-size:11px;color:#94A3B8;margin-top:3px;">
                  Analógico: Mover • A: Disparar • B: Dash • X: Pulso Nova • Y: Escudo
                </div>
              </div>
              <script>
                const canvas = document.getElementById('game');
                const ctx = canvas.getContext('2d');
                let W = canvas.width = window.innerWidth;
                let H = canvas.height = window.innerHeight;
                window.addEventListener('resize', () => {
                  W = canvas.width = window.innerWidth;
                  H = canvas.height = window.innerHeight;
                });

                const keys = {};
                window.addEventListener('keydown', e => keys[e.code] = true);
                window.addEventListener('keyup', e => keys[e.code] = false);

                const player = { x: W * 0.5, y: H * 0.55, vx: 0, vy: 0, r: 16, hp: 100, shield: 0, dashCd: 0, fireCd: 0, novaCd: 0 };
                let score = 0, wave = 1, t = 0;
                const bullets = [], enemies = [], particles = [];

                function spawnEnemy() {
                  const side = Math.floor(Math.random() * 4);
                  let x = 0, y = 0;
                  if (side === 0) { x = Math.random() * W; y = -24; }
                  else if (side === 1) { x = W + 24; y = Math.random() * H; }
                  else if (side === 2) { x = Math.random() * W; y = H + 24; }
                  else { x = -24; y = Math.random() * H; }
                  enemies.push({ x, y, r: 13 + Math.random() * 8, speed: 65 + wave * 12 + Math.random() * 40, hp: 1 + Math.floor(wave / 3) });
                }

                function burst(x, y, color, n = 12) {
                  for (let i = 0; i < n; i++) {
                    const a = Math.random() * Math.PI * 2;
                    const sp = 50 + Math.random() * 190;
                    particles.push({ x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: 0.45 + Math.random() * 0.3, color });
                  }
                }

                let last = performance.now(), spawnTimer = 0;
                function loop(now) {
                  const dt = Math.min((now - last) / 1000, 0.05);
                  last = now;
                  t += dt;

                  const si = window.StormInput || { lx: 0, ly: 0, buttons: [] };
                  const btns = new Set(si.buttons || []);
                  let ax = si.lx || 0, ay = si.ly || 0;
                  if (keys['ArrowLeft'] || keys['KeyA']) ax -= 1;
                  if (keys['ArrowRight'] || keys['KeyD']) ax += 1;
                  if (keys['ArrowUp'] || keys['KeyW']) ay -= 1;
                  if (keys['ArrowDown'] || keys['KeyS']) ay += 1;
                  const mag = Math.hypot(ax, ay);
                  if (mag > 1) { ax /= mag; ay /= mag; }

                  const firing = btns.has('A') || keys['Space'] || keys['KeyZ'];
                  const dashing = btns.has('B') || keys['KeyX'] || keys['ShiftLeft'];
                  const nova = btns.has('X') || keys['KeyC'];
                  const shieldBtn = btns.has('Y') || keys['KeyV'];

                  player.fireCd = Math.max(0, player.fireCd - dt);
                  player.dashCd = Math.max(0, player.dashCd - dt);
                  player.novaCd = Math.max(0, player.novaCd - dt);
                  player.shield = shieldBtn ? 0.25 : Math.max(0, player.shield - dt);

                  const speed = (dashing && player.dashCd <= 0) ? 760 : 310;
                  if (dashing && player.dashCd <= 0 && mag > 0.1) {
                    player.dashCd = 0.65;
                    burst(player.x, player.y, '#00E5FF', 14);
                  }
                  player.x = Math.max(24, Math.min(W - 24, player.x + ax * speed * dt));
                  player.y = Math.max(60, Math.min(H - 24, player.y + ay * speed * dt));

                  if (firing && player.fireCd <= 0) {
                    player.fireCd = 0.12;
                    const aimAngle = mag > 0.2 ? Math.atan2(ay, ax) : -Math.PI / 2;
                    bullets.push({ x: player.x, y: player.y, vx: Math.cos(aimAngle) * 620, vy: Math.sin(aimAngle) * 620, life: 1.5 });
                  }

                  if (nova && player.novaCd <= 0) {
                    player.novaCd = 2.0;
                    burst(player.x, player.y, '#FFB300', 26);
                    for (let i = enemies.length - 1; i >= 0; i--) {
                      const e = enemies[i];
                      if (Math.hypot(e.x - player.x, e.y - player.y) < 170) {
                        burst(e.x, e.y, '#FF8C1A', 10);
                        enemies.splice(i, 1);
                        score += 25;
                      }
                    }
                  }

                  spawnTimer += dt;
                  if (spawnTimer > Math.max(0.28, 1.1 - wave * 0.08)) {
                    spawnTimer = 0;
                    spawnEnemy();
                  }
                  wave = 1 + Math.floor(score / 250);

                  ctx.fillStyle = '#070B14';
                  ctx.fillRect(0, 0, W, H);
                  ctx.strokeStyle = 'rgba(0, 229, 255, 0.07)';
                  ctx.lineWidth = 1;
                  for (let gx = (t * 25) % 48; gx < W; gx += 48) {
                    ctx.beginPath(); ctx.moveTo(gx, 0); ctx.lineTo(gx, H); ctx.stroke();
                  }
                  for (let gy = (t * 25) % 48; gy < H; gy += 48) {
                    ctx.beginPath(); ctx.moveTo(0, gy); ctx.lineTo(W, gy); ctx.stroke();
                  }

                  for (let i = bullets.length - 1; i >= 0; i--) {
                    const b = bullets[i];
                    b.x += b.vx * dt; b.y += b.vy * dt; b.life -= dt;
                    ctx.fillStyle = '#00E5FF';
                    ctx.beginPath(); ctx.arc(b.x, b.y, 5, 0, Math.PI * 2); ctx.fill();
                    if (b.life <= 0) bullets.splice(i, 1);
                  }

                  for (let i = enemies.length - 1; i >= 0; i--) {
                    const e = enemies[i];
                    const ang = Math.atan2(player.y - e.y, player.x - e.x);
                    e.x += Math.cos(ang) * e.speed * dt;
                    e.y += Math.sin(ang) * e.speed * dt;

                    ctx.fillStyle = '#FF8C1A';
                    ctx.beginPath(); ctx.arc(e.x, e.y, e.r, 0, Math.PI * 2); ctx.fill();
                    ctx.strokeStyle = '#FFB300'; ctx.lineWidth = 2; ctx.stroke();

                    let destroyed = false;
                    for (let j = bullets.length - 1; j >= 0; j--) {
                      const b = bullets[j];
                      if (Math.hypot(e.x - b.x, e.y - b.y) < e.r + 6) {
                        bullets.splice(j, 1);
                        e.hp--;
                        if (e.hp <= 0) {
                          burst(e.x, e.y, '#FF8C1A', 12);
                          enemies.splice(i, 1);
                          score += 15;
                          destroyed = true;
                          break;
                        }
                      }
                    }
                    if (destroyed) continue;

                    if (Math.hypot(e.x - player.x, e.y - player.y) < e.r + player.r) {
                      burst(e.x, e.y, '#EF4444', 14);
                      enemies.splice(i, 1);
                      if (player.shield <= 0) {
                        player.hp = Math.max(0, player.hp - 15);
                        if (player.hp === 0) {
                          player.hp = 100; score = 0; enemies.length = 0;
                        }
                      }
                    }
                  }

                  for (let i = particles.length - 1; i >= 0; i--) {
                    const pt = particles[i];
                    pt.x += pt.vx * dt; pt.y += pt.vy * dt; pt.life -= dt;
                    ctx.globalAlpha = Math.max(0, pt.life * 1.5);
                    ctx.fillStyle = pt.color;
                    ctx.fillRect(pt.x, pt.y, 4, 4);
                    ctx.globalAlpha = 1;
                    if (pt.life <= 0) particles.splice(i, 1);
                  }

                  if (player.shield > 0) {
                    ctx.strokeStyle = '#00E5FF'; ctx.lineWidth = 3;
                    ctx.beginPath(); ctx.arc(player.x, player.y, player.r + 10, 0, Math.PI * 2); ctx.stroke();
                  }
                  ctx.fillStyle = '#00E5FF';
                  ctx.beginPath(); ctx.arc(player.x, player.y, player.r, 0, Math.PI * 2); ctx.fill();
                  ctx.strokeStyle = '#FFFFFF'; ctx.lineWidth = 2.5; ctx.stroke();

                  document.getElementById('score').textContent = score;
                  document.getElementById('hp').textContent = player.hp;
                  document.getElementById('wave').textContent = wave;
                  requestAnimationFrame(loop);
                }
                requestAnimationFrame(loop);
              </script>
            </body>
            </html>
        """.trimIndent()
    }
}

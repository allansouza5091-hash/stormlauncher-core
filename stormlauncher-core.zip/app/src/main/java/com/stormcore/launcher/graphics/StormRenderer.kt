package com.stormcore.launcher.graphics

import android.opengl.EGL14
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import com.stormcore.launcher.config.LauncherConfig
import com.stormcore.launcher.controls.InputState
import com.stormcore.launcher.diagnostics.AppLogger
import com.stormcore.launcher.diagnostics.HardwareTelemetry
import java.nio.FloatBuffer
import java.util.concurrent.atomic.AtomicReference
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class StormRenderer(
    initialConfig: LauncherConfig,
    private val customFragmentShader: String? = null,
    private val onFpsUpdated: (Float) -> Unit,
    private val onGpuInfoReady: (renderer: String, vendor: String, version: String) -> Unit
) : GLSurfaceView.Renderer {

    private val configRef = AtomicReference(initialConfig)
    private val inputRef = AtomicReference(InputState())

    @Volatile
    var isPaused: Boolean = false

    private var sceneProgram: ShaderProgram? = null
    private var postProgram: ShaderProgram? = null
    private var quadBuffer: FloatBuffer? = null
    private var vaoId: Int = 0
    private var vboId: Int = 0

    // Offscreen FBO for internal resolution scaling & multi-pass post-processing
    private var fboId: Int = 0
    private var fboTexId: Int = 0
    private var surfaceWidth: Int = 1280
    private var surfaceHeight: Int = 720
    private var fboWidth: Int = 0
    private var fboHeight: Int = 0
    private var currentScaleFactor: Float = initialConfig.resolutionScale.factor
    private var lastVsyncState: Boolean? = null

    private var startTimeNs: Long = System.nanoTime()
    private var accumulatedTimeSec: Float = 0f
    private var lastFrameNs: Long = System.nanoTime()

    private var fpsFrameCount: Int = 0
    private var fpsLastSampleNs: Long = System.nanoTime()
    private var actionPulse: Float = 0f

    fun updateConfig(config: LauncherConfig) {
        configRef.set(config)
    }

    fun updateInput(state: InputState) {
        val prev = inputRef.getAndSet(state)
        if (state.pressedButtons.size > prev.pressedButtons.size) {
            actionPulse = 1.0f
        }
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        val renderer = GLES30.glGetString(GLES30.GL_RENDERER).orEmpty()
        val vendor = GLES30.glGetString(GLES30.GL_VENDOR).orEmpty()
        val version = GLES30.glGetString(GLES30.GL_VERSION).orEmpty()

        HardwareTelemetry.updateGpuInfo(renderer, vendor, version)
        onGpuInfoReady(renderer, vendor, version)
        AppLogger.shader("Renderer", "Contexto OpenGL ES 3.0 criado: $renderer | $version")

        GLES30.glDisable(GLES30.GL_DEPTH_TEST)
        GLES30.glClearColor(0.035f, 0.052f, 0.095f, 1.0f)

        setupQuadGeometry()

        val activeFrag = customFragmentShader?.takeIf { it.isNotBlank() }
        var customProgram: ShaderProgram? = null
        if (activeFrag != null) {
            val candidate = ShaderProgram(
                name = "UserCartridgeGLSL",
                vertexSource = StormShaders.FULLSCREEN_VERTEX_SHADER,
                fragmentSource = activeFrag
            )
            if (candidate.isValid) {
                customProgram = candidate
            } else {
                AppLogger.w("Renderer", "Shader do usuário falhou; revertendo para o shader padrão StormEnergyScene.")
            }
        }

        sceneProgram = customProgram ?: ShaderProgram(
            name = "StormEnergyScene",
            vertexSource = StormShaders.FULLSCREEN_VERTEX_SHADER,
            fragmentSource = StormShaders.ENERGY_SCENE_FRAGMENT_SHADER
        )
        postProgram = ShaderProgram(
            name = "StormPostProcess",
            vertexSource = StormShaders.FULLSCREEN_VERTEX_SHADER,
            fragmentSource = StormShaders.POST_PROCESS_FRAGMENT_SHADER
        )

        startTimeNs = System.nanoTime()
        lastFrameNs = startTimeNs
        fpsLastSampleNs = startTimeNs
        fpsFrameCount = 0
        lastVsyncState = null
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        surfaceWidth = width.coerceAtLeast(1)
        surfaceHeight = height.coerceAtLeast(1)
        val scale = configRef.get().resolutionScale.factor
        rebuildFboIfNeeded(scale)
        AppLogger.shader(
            "Renderer",
            "Superfície redimensionada: ${surfaceWidth}x${surfaceHeight} (FBO interno: ${fboWidth}x${fboHeight} @ ${scale}x)"
        )
    }

    override fun onDrawFrame(gl: GL10?) {
        val cfg = configRef.get()
        applyVsyncIfChanged(cfg.vsyncEnabled)
        enforceFpsLimit(cfg.fpsLimit.fps)

        val nowNs = System.nanoTime()
        val dtSec = ((nowNs - lastFrameNs) / 1_000_000_000.0).toFloat().coerceIn(0f, 0.1f)
        lastFrameNs = nowNs

        if (!isPaused) {
            accumulatedTimeSec += dtSec
        }
        actionPulse = (actionPulse - dtSec * 2.8f).coerceAtLeast(0f)

        val scale = cfg.resolutionScale.factor
        if (kotlin.math.abs(scale - currentScaleFactor) > 0.01f || fboId == 0) {
            rebuildFboIfNeeded(scale)
        }

        val input = inputRef.get()
        val intensity = cfg.performanceProfile.shaderIntensity

        val scene = sceneProgram
        val post = postProgram
        if (scene == null || !scene.isValid || post == null || !post.isValid) {
            GLES30.glViewport(0, 0, surfaceWidth, surfaceHeight)
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)
            return
        }

        GLES30.glBindVertexArray(vaoId)

        // Pass 1: Render energy shader to internal scaled FBO
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fboId)
        GLES30.glViewport(0, 0, fboWidth, fboHeight)
        scene.use()
        scene.setStandardUniforms(
            width = fboWidth.toFloat(),
            height = fboHeight.toFloat(),
            timeSec = accumulatedTimeSec,
            intensity = intensity,
            mode = cfg.shaderFilter.modeInt
        )
        scene.setInteractiveUniforms(input.analogX, input.analogY, actionPulse)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)

        // Pass 2: Blit & apply post-processing filter to screen framebuffer
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
        GLES30.glViewport(0, 0, surfaceWidth, surfaceHeight)
        post.use()
        post.setStandardUniforms(
            width = fboWidth.toFloat(),
            height = fboHeight.toFloat(),
            timeSec = accumulatedTimeSec,
            intensity = intensity,
            mode = cfg.shaderFilter.modeInt
        )
        post.bindSceneTexture(0, fboTexId)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)

        GLES30.glBindVertexArray(0)

        // Update smoothed FPS telemetry
        fpsFrameCount++
        val elapsedFpsNs = nowNs - fpsLastSampleNs
        if (elapsedFpsNs >= 350_000_000L) {
            val fps = (fpsFrameCount * 1_000_000_000.0 / elapsedFpsNs).toFloat()
            fpsFrameCount = 0
            fpsLastSampleNs = nowNs
            onFpsUpdated(fps)
        }
    }

    private fun setupQuadGeometry() {
        quadBuffer = ShaderProgram.createQuadBuffer()
        val vaos = IntArray(1)
        val vbos = IntArray(1)
        GLES30.glGenVertexArrays(1, vaos, 0)
        GLES30.glGenBuffers(1, vbos, 0)
        vaoId = vaos[0]
        vboId = vbos[0]

        GLES30.glBindVertexArray(vaoId)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vboId)
        GLES30.glBufferData(
            GLES30.GL_ARRAY_BUFFER,
            16 * 4,
            quadBuffer,
            GLES30.GL_STATIC_DRAW
        )

        val stride = 4 * 4
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 2, GLES30.GL_FLOAT, false, stride, 0)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 2, GLES30.GL_FLOAT, false, stride, 2 * 4)

        GLES30.glBindVertexArray(0)
    }

    private fun rebuildFboIfNeeded(scale: Float) {
        currentScaleFactor = scale
        val targetW = (surfaceWidth * scale).toInt().coerceIn(160, 4096)
        val targetH = (surfaceHeight * scale).toInt().coerceIn(90, 4096)
        if (fboId != 0 && targetW == fboWidth && targetH == fboHeight) return

        destroyFbo()
        fboWidth = targetW
        fboHeight = targetH

        val textures = IntArray(1)
        val fbos = IntArray(1)
        GLES30.glGenTextures(1, textures, 0)
        GLES30.glGenFramebuffers(1, fbos, 0)
        fboTexId = textures[0]
        fboId = fbos[0]

        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, fboTexId)
        GLES30.glTexImage2D(
            GLES30.GL_TEXTURE_2D,
            0,
            GLES30.GL_RGBA8,
            fboWidth,
            fboHeight,
            0,
            GLES30.GL_RGBA,
            GLES30.GL_UNSIGNED_BYTE,
            null
        )
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)

        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fboId)
        GLES30.glFramebufferTexture2D(
            GLES30.GL_FRAMEBUFFER,
            GLES30.GL_COLOR_ATTACHMENT0,
            GLES30.GL_TEXTURE_2D,
            fboTexId,
            0
        )

        val status = GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER)
        if (status != GLES30.GL_FRAMEBUFFER_COMPLETE) {
            AppLogger.e("Renderer", "FBO incompleto (status=0x${Integer.toHexString(status)})")
        }
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, 0)
    }

    private fun destroyFbo() {
        if (fboId != 0) {
            GLES30.glDeleteFramebuffers(1, intArrayOf(fboId), 0)
            fboId = 0
        }
        if (fboTexId != 0) {
            GLES30.glDeleteTextures(1, intArrayOf(fboTexId), 0)
            fboTexId = 0
        }
    }

    private fun applyVsyncIfChanged(vsyncEnabled: Boolean) {
        if (lastVsyncState == vsyncEnabled) return
        lastVsyncState = vsyncEnabled
        try {
            val display = EGL14.eglGetCurrentDisplay()
            if (display != EGL14.EGL_NO_DISPLAY) {
                EGL14.eglSwapInterval(display, if (vsyncEnabled) 1 else 0)
            }
        } catch (_: Throwable) {
            // Some software EGL drivers ignore swapInterval; ignore safely
        }
    }

    private fun enforceFpsLimit(targetFps: Int) {
        if (targetFps <= 0) return
        val targetFrameNs = 1_000_000_000L / targetFps
        val elapsedNs = System.nanoTime() - lastFrameNs
        val remainingNs = targetFrameNs - elapsedNs
        if (remainingNs > 1_000_000L) {
            try {
                Thread.sleep(remainingNs / 1_000_000L, (remainingNs % 1_000_000L).toInt())
            } catch (_: InterruptedException) {
            }
        }
    }

    fun release() {
        destroyFbo()
        sceneProgram?.release()
        postProgram?.release()
        if (vboId != 0) {
            GLES30.glDeleteBuffers(1, intArrayOf(vboId), 0)
            vboId = 0
        }
        if (vaoId != 0) {
            GLES30.glDeleteVertexArrays(1, intArrayOf(vaoId), 0)
            vaoId = 0
        }
    }
}

package com.stormcore.launcher.config

import android.content.Context
import android.content.SharedPreferences
import com.stormcore.launcher.diagnostics.AppLogger
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ConfigRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _config = MutableStateFlow(loadConfig())
    val config: StateFlow<LauncherConfig> = _config.asStateFlow()

    private fun loadConfig(): LauncherConfig {
        val defaults = LauncherConfig.defaultHudPositions()
        val loadedHud = defaults.mapValues { (id, def) ->
            val x = prefs.getFloat("hud_${id}_x", def.xPercent).coerceIn(0.05f, 0.95f)
            val y = prefs.getFloat("hud_${id}_y", def.yPercent).coerceIn(0.08f, 0.94f)
            def.copy(xPercent = x, yPercent = y)
        }

        return LauncherConfig(
            performanceProfile = PerformanceProfile.fromId(prefs.getString(KEY_PERF_PROFILE, null)),
            resolutionScale = ResolutionScale.fromFactor(prefs.getFloat(KEY_RES_SCALE, 1.0f)),
            fpsLimit = FpsLimit.fromFps(prefs.getInt(KEY_FPS_LIMIT, 60)),
            shaderFilter = ShaderFilter.fromMode(prefs.getInt(KEY_SHADER_FILTER, 0)),
            vsyncEnabled = prefs.getBoolean(KEY_VSYNC, true),
            showFpsCounter = prefs.getBoolean(KEY_SHOW_FPS, true),
            virtualControlsEnabled = prefs.getBoolean(KEY_VIRTUAL_CONTROLS, true),
            floatingAnalog = prefs.getBoolean(KEY_FLOATING_ANALOG, false),
            controlsOpacityPercent = prefs.getInt(KEY_OPACITY, 75).coerceIn(10, 100),
            controlsScalePercent = prefs.getInt(KEY_SCALE, 100).coerceIn(70, 140),
            analogDeadzone = prefs.getFloat(KEY_DEADZONE, 0.12f).coerceIn(0.04f, 0.40f),
            safTreeUri = prefs.getString(KEY_SAF_URI, null),
            hudPositions = loadedHud
        )
    }

    fun updateConfig(transform: (LauncherConfig) -> LauncherConfig) {
        val updated = transform(_config.value)
        _config.value = updated
        persistConfig(updated)
    }

    fun saveHudPositions(positions: Map<String, HudElementPos>) {
        val updated = _config.value.copy(hudPositions = positions)
        _config.value = updated
        prefs.edit().apply {
            positions.forEach { (id, pos) ->
                putFloat("hud_${id}_x", pos.xPercent.coerceIn(0.05f, 0.95f))
                putFloat("hud_${id}_y", pos.yPercent.coerceIn(0.08f, 0.94f))
            }
        }.apply()
        AppLogger.input("HUD", "Coordenadas personalizadas de ${positions.size} elementos salvas.")
    }

    fun resetHudPositions(): Map<String, HudElementPos> {
        val defaults = LauncherConfig.defaultHudPositions()
        saveHudPositions(defaults)
        AppLogger.input("HUD", "Layout de controles restaurado para o padrão de fábrica.")
        return defaults
    }

    private fun persistConfig(cfg: LauncherConfig) {
        prefs.edit().apply {
            putString(KEY_PERF_PROFILE, cfg.performanceProfile.id)
            putFloat(KEY_RES_SCALE, cfg.resolutionScale.factor)
            putInt(KEY_FPS_LIMIT, cfg.fpsLimit.fps)
            putInt(KEY_SHADER_FILTER, cfg.shaderFilter.modeInt)
            putBoolean(KEY_VSYNC, cfg.vsyncEnabled)
            putBoolean(KEY_SHOW_FPS, cfg.showFpsCounter)
            putBoolean(KEY_VIRTUAL_CONTROLS, cfg.virtualControlsEnabled)
            putBoolean(KEY_FLOATING_ANALOG, cfg.floatingAnalog)
            putInt(KEY_OPACITY, cfg.controlsOpacityPercent)
            putInt(KEY_SCALE, cfg.controlsScalePercent)
            putFloat(KEY_DEADZONE, cfg.analogDeadzone)
            if (cfg.safTreeUri != null) {
                putString(KEY_SAF_URI, cfg.safTreeUri)
            } else {
                remove(KEY_SAF_URI)
            }
        }.apply()
    }

    companion object {
        private const val PREFS_NAME = "stormlauncher_core_prefs"
        private const val KEY_PERF_PROFILE = "perf_profile"
        private const val KEY_RES_SCALE = "res_scale"
        private const val KEY_FPS_LIMIT = "fps_limit"
        private const val KEY_SHADER_FILTER = "shader_filter"
        private const val KEY_VSYNC = "vsync_enabled"
        private const val KEY_SHOW_FPS = "show_fps_counter"
        private const val KEY_VIRTUAL_CONTROLS = "virtual_controls_enabled"
        private const val KEY_FLOATING_ANALOG = "floating_analog"
        private const val KEY_OPACITY = "controls_opacity_percent"
        private const val KEY_SCALE = "controls_scale_percent"
        private const val KEY_DEADZONE = "analog_deadzone"
        private const val KEY_SAF_URI = "saf_tree_uri"
    }
}

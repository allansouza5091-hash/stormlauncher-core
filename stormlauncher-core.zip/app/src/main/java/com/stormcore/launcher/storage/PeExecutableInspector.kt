package com.stormcore.launcher.storage

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class PeHeaderSummary(
    val isValidPe: Boolean,
    val isDosMzOnly: Boolean,
    val archLabel: String,
    val subsystemLabel: String
)

object PeExecutableInspector {

    fun inspectFile(file: File): PeHeaderSummary {
        return try {
            file.inputStream().use { inspectStream(it) }
        } catch (_: Exception) {
            PeHeaderSummary(false, false, "Desconhecido", "I/O Erro")
        }
    }

    fun inspectUri(context: Context, uri: Uri): PeHeaderSummary {
        return try {
            context.contentResolver.openInputStream(uri)?.use { inspectStream(it) }
                ?: PeHeaderSummary(false, false, "Desconhecido", "Stream nulo")
        } catch (_: Exception) {
            PeHeaderSummary(false, false, "Desconhecido", "I/O Erro")
        }
    }

    private fun inspectStream(stream: InputStream): PeHeaderSummary {
        val header = ByteArray(4096)
        val bytesRead = stream.read(header)
        if (bytesRead < 64) {
            return PeHeaderSummary(false, false, "Inválido", "Arquivo muito pequeno")
        }

        // Check MZ signature (0x4D 0x5A)
        if (header[0] != 0x4D.toByte() || header[1] != 0x5A.toByte()) {
            return PeHeaderSummary(false, false, "Não-PE", "Sem assinatura MZ")
        }

        val peOffset = ByteBuffer.wrap(header, 0x3C, 4)
            .order(ByteOrder.LITTLE_ENDIAN)
            .int

        if (peOffset < 0 || peOffset + 24 >= bytesRead) {
            return PeHeaderSummary(false, true, "DOS 16-bit / MZ", "Sem cabeçalho PE32")
        }

        // Check PE\0\0 signature
        if (header[peOffset] != 0x50.toByte() ||
            header[peOffset + 1] != 0x45.toByte() ||
            header[peOffset + 2] != 0x00.toByte() ||
            header[peOffset + 3] != 0x00.toByte()
        ) {
            return PeHeaderSummary(false, true, "DOS 16-bit / MZ", "Executável legado")
        }

        val machine = ByteBuffer.wrap(header, peOffset + 4, 2)
            .order(ByteOrder.LITTLE_ENDIAN)
            .short.toInt() and 0xFFFF

        val arch = when (machine) {
            0x014C -> "x86 (32-bit)"
            0x8664 -> "x86-64 (64-bit)"
            0xAA64 -> "ARM64 Windows"
            0x01C4 -> "ARMv7 Windows"
            else -> "Arch 0x${machine.toString(16)}"
        }

        val optMagic = if (peOffset + 26 < bytesRead) {
            ByteBuffer.wrap(header, peOffset + 24, 2)
                .order(ByteOrder.LITTLE_ENDIAN)
                .short.toInt() and 0xFFFF
        } else 0

        val subsystem = when (optMagic) {
            0x010B -> "PE32 (Win32)"
            0x020B -> "PE32+ (Win64)"
            else -> "PE"
        }

        return PeHeaderSummary(
            isValidPe = true,
            isDosMzOnly = false,
            archLabel = arch,
            subsystemLabel = subsystem
        )
    }
}
